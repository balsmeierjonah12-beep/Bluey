package de.ps5test

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.input.InputManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class MainActivity : Activity(), SensorEventListener {
    private lateinit var dash: Dash
    private val keys = HashSet<Int>()
    private val ax = FloatArray(8) // lx ly rx ry l2 r2 hatx haty
    private val gyro = FloatArray(3)
    private val acc = FloatArray(3)
    private var sensorMgr: SensorManager? = null
    private var devName = "Kein Controller erkannt"
    private var sensorInfo = "Gyro: kein Controller"
    private var audioInfo = "Ausgabe: Standard"
    private var sink: AudioDeviceInfo? = null
    @Volatile private var playing = false

    private val names = listOf(
        KeyEvent.KEYCODE_BUTTON_A to "\u2715", KeyEvent.KEYCODE_BUTTON_B to "\u25CB",
        KeyEvent.KEYCODE_BUTTON_X to "\u25A1", KeyEvent.KEYCODE_BUTTON_Y to "\u25B3",
        KeyEvent.KEYCODE_BUTTON_L1 to "L1", KeyEvent.KEYCODE_BUTTON_R1 to "R1",
        KeyEvent.KEYCODE_BUTTON_L2 to "L2", KeyEvent.KEYCODE_BUTTON_R2 to "R2",
        KeyEvent.KEYCODE_BUTTON_THUMBL to "L3", KeyEvent.KEYCODE_BUTTON_THUMBR to "R3",
        KeyEvent.KEYCODE_BUTTON_SELECT to "Create", KeyEvent.KEYCODE_BUTTON_START to "Options",
        KeyEvent.KEYCODE_BUTTON_MODE to "PS",
        KeyEvent.KEYCODE_DPAD_UP to "\u2191", KeyEvent.KEYCODE_DPAD_DOWN to "\u2193",
        KeyEvent.KEYCODE_DPAD_LEFT to "\u2190", KeyEvent.KEYCODE_DPAD_RIGHT to "\u2192"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0F1115.toInt())
        dash = Dash(this)
        root.addView(dash, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this)
        fun btn(t: String, f: () -> Unit) {
            val bt = Button(this)
            bt.text = t
            bt.setOnClickListener { f() }
            row.addView(bt, LinearLayout.LayoutParams(0, -2, 1f))
        }
        btn("Vibration") { rumble() }
        btn("Ausgabe") { pickSink() }
        btn("Ton an/aus") { toggleTone() }
        root.addView(row)
        setContentView(root)
        val im = getSystemService(Context.INPUT_SERVICE) as InputManager
        im.registerInputDeviceListener(object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(id: Int) { setupSensors() }
            override fun onInputDeviceRemoved(id: Int) { setupSensors() }
            override fun onInputDeviceChanged(id: Int) {}
        }, null)
    }

    override fun onResume() { super.onResume(); setupSensors() }
    override fun onPause() { super.onPause(); sensorMgr?.unregisterListener(this); sensorMgr = null; playing = false }

    private fun isPad(s: Int) = (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
        (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD

    private fun pad(): InputDevice? {
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (isPad(d.sources)) return d
        }
        return null
    }

    private fun setupSensors() {
        sensorMgr?.unregisterListener(this)
        sensorMgr = null
        val d = pad()
        devName = d?.name ?: "Kein Controller erkannt"
        if (d == null) { sensorInfo = "Gyro: kein Controller"; dash.invalidate(); return }
        if (Build.VERSION.SDK_INT < 31) { sensorInfo = "Gyro: braucht Android 12 oder neuer"; dash.invalidate(); return }
        val sm = d.sensorManager
        val g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        val a = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (g == null && a == null) { sensorInfo = "Gyro: Controller meldet keine Sensoren"; dash.invalidate(); return }
        if (g != null) sm.registerListener(this, g, SensorManager.SENSOR_DELAY_GAME)
        if (a != null) sm.registerListener(this, a, SensorManager.SENSOR_DELAY_GAME)
        sensorMgr = sm
        sensorInfo = "Gyro: aktiv"
        dash.invalidate()
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_GYROSCOPE) for (i in 0..2) gyro[i] = e.values[i]
        else if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) for (i in 0..2) acc[i] = e.values[i]
        dash.invalidate()
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (!isPad(e.source)) return super.dispatchGenericMotionEvent(e)
        ax[0] = e.getAxisValue(MotionEvent.AXIS_X)
        ax[1] = e.getAxisValue(MotionEvent.AXIS_Y)
        ax[2] = e.getAxisValue(MotionEvent.AXIS_Z)
        ax[3] = e.getAxisValue(MotionEvent.AXIS_RZ)
        ax[4] = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
        ax[5] = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
        ax[6] = e.getAxisValue(MotionEvent.AXIS_HAT_X)
        ax[7] = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        dash.invalidate()
        return true
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (!isPad(e.source)) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN) keys.add(e.keyCode)
        else if (e.action == KeyEvent.ACTION_UP) keys.remove(e.keyCode)
        dash.invalidate()
        return true
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun rumble() {
        val d = pad()
        if (d == null) { toast("Kein Controller erkannt"); return }
        if (Build.VERSION.SDK_INT < 31) { toast("Vibration braucht Android 12 oder neuer"); return }
        val v = d.vibratorManager.defaultVibrator
        if (!v.hasVibrator()) { toast("Controller meldet keine Vibration"); return }
        v.vibrate(VibrationEffect.createOneShot(700, 255))
    }

    private fun typeName(t: Int) = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Handy-Lautsprecher"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth"
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Kabel"
        else -> "Typ $t"
    }

    private fun pickSink() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val devs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val labels = devs.map { "${it.productName} (${typeName(it.type)})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Ausgabe wählen").setItems(labels) { _, i ->
            sink = devs[i]
            audioInfo = "Ausgabe: " + labels[i]
            dash.invalidate()
        }.show()
    }

    private fun toggleTone() {
        if (playing) { playing = false; return }
        val sr = 48000
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sr)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(minBuf, sr))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        val s = sink
        if (s != null && !t.setPreferredDevice(s)) toast("Gerät konnte nicht gewählt werden")
        playing = true
        t.play()
        Thread {
            try {
                val buf = ShortArray(2400)
                var ph = 0.0
                while (playing) {
                    for (i in buf.indices) {
                        buf[i] = (sin(ph) * 9000).toInt().toShort()
                        ph += 2 * PI * 440 / sr
                        if (ph > 2 * PI) ph -= 2 * PI
                    }
                    t.write(buf, 0, buf.size)
                }
            } catch (_: Exception) {
            }
            try { t.stop(); t.release() } catch (_: Exception) {}
        }.start()
    }

    inner class Dash(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val d = resources.displayMetrics.density

        private fun pressed(k: Int): Boolean = keys.contains(k) ||
            (k == KeyEvent.KEYCODE_DPAD_UP && ax[7] < -0.5f) || (k == KeyEvent.KEYCODE_DPAD_DOWN && ax[7] > 0.5f) ||
            (k == KeyEvent.KEYCODE_DPAD_LEFT && ax[6] < -0.5f) || (k == KeyEvent.KEYCODE_DPAD_RIGHT && ax[6] > 0.5f)

        private fun stick(cv: Canvas, cx: Float, cy: Float, r: Float, x: Float, y: Float) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = 0xFF3A3F4B.toInt()
            cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.FILL; p.color = 0xFF60A5FA.toInt()
            cv.drawCircle(cx + x * r * 0.8f, cy + y * r * 0.8f, 9 * d, p)
        }

        private fun bar(cv: Canvas, label: String, v: Float, x: Float, y: Float, w: Float, centered: Boolean) {
            p.style = Paint.Style.FILL; p.color = Color.LTGRAY; p.textSize = 12 * d
            cv.drawText(label, x, y, p)
            val l = x + 62 * d; val bw = w - 62 * d; val top = y - 11 * d
            p.color = 0xFF2A2E38.toInt()
            cv.drawRoundRect(l, top, l + bw, top + 14 * d, 7 * d, 7 * d, p)
            p.color = 0xFF60A5FA.toInt()
            if (centered) {
                val f = v.coerceIn(-1f, 1f); val m = l + bw / 2
                cv.drawRect(min(m, m + f * bw / 2), top, max(m, m + f * bw / 2), top + 14 * d, p)
            } else cv.drawRoundRect(l, top, l + bw * v.coerceIn(0f, 1f), top + 14 * d, 7 * d, 7 * d, p)
        }

        private fun text(cv: Canvas, s: String, x: Float, y: Float, sz: Float = 13f) {
            p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textSize = sz * d
            cv.drawText(s, x, y, p)
        }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat(); val m = 12 * d
            var y = 28 * d
            text(cv, devName, m, y, 16f)
            val r = 50 * d; val cy = y + r + 14 * d
            stick(cv, w * 0.27f, cy, r, ax[0], ax[1]); stick(cv, w * 0.73f, cy, r, ax[2], ax[3])
            y = cy + r + 26 * d
            bar(cv, "L2", ax[4], m, y, w - 2 * m, false); y += 26 * d
            bar(cv, "R2", ax[5], m, y, w - 2 * m, false); y += 22 * d
            var x = m
            for ((k, n) in names) {
                val cw = 52 * d
                if (x + cw > w - m) { x = m; y += 36 * d }
                p.style = Paint.Style.FILL
                p.color = if (pressed(k)) 0xFF16A34A.toInt() else 0xFF2A2E38.toInt()
                cv.drawRoundRect(x, y, x + cw - 6 * d, y + 30 * d, 8 * d, 8 * d, p)
                p.color = Color.WHITE; p.textSize = 12 * d; p.textAlign = Paint.Align.CENTER
                cv.drawText(n, x + (cw - 6 * d) / 2, y + 20 * d, p)
                p.textAlign = Paint.Align.LEFT
                x += cw
            }
            y += 56 * d
            val gl = listOf("Gyro X", "Gyro Y", "Gyro Z")
            for (i in 0..2) { bar(cv, gl[i], gyro[i] / 6f, m, y, w - 2 * m, true); y += 24 * d }
            y += 6 * d
            text(cv, String.format("Gyro °/s: %.0f  %.0f  %.0f", Math.toDegrees(gyro[0].toDouble()),
                Math.toDegrees(gyro[1].toDouble()), Math.toDegrees(gyro[2].toDouble())), m, y); y += 20 * d
            text(cv, String.format("Beschl. m/s²: %.1f  %.1f  %.1f", acc[0], acc[1], acc[2]), m, y); y += 20 * d
            text(cv, sensorInfo, m, y); y += 20 * d
            text(cv, audioInfo, m, y)
        }
    }
}
