# Bluey für Android (eigenständig, mit Gemini)

Bluey ist ein reiner KI-Helfer auf dem Handy. Es wird **kein Mac und kein Desktop** gebraucht.

- **Freihändig:** Sag „Hey Bluey“ (oder „Hey Pinky“, „Hey Greeny“ …), dann wacht er auf. Du musst nichts tippen.
- **Er spricht Deutsch** (und antwortet in deiner Sprache, wenn du eine andere sprichst) mit einer süßen Stimme.
  Bluey und Greeny sind Jungs, Pinky ist ein Mädchen. Dazu erscheint seine Antwort als kleine Sprechblase.
- **Farben:** In den Einstellungen wählst du seine Farbe. Je nach Farbe heißt er anders, hört auf einen anderen Namen
  und hat eine andere Stimme:

  | Farbe | Name | Stimme |
  | --- | --- | --- |
  | Blau | Bluey | Junge (Puck) |
  | Pink | Pinky | Mädchen (Leda) |
  | Grün | Greeny | Junge (Fenrir) |
  | Lila | Purply | Mädchen (Aoede) |
  | Orange | Orangy | Mädchen (Kore) |

- **Er schläft mit Zzz:** Solange er nicht wach ist, hat er die Augen zu und kleine Z's steigen auf. Die Kamera ist dann aus.
- **Aufwecken:** einmal auf den Bildschirm tippen, oder „Hey <Name>“ sagen. Doppeltippen schickt ihn wieder schlafen.
  Tippst du ihn an, wenn er wach ist, hüpft er vergnügt.
- **Er sieht live:** Die Frontkamera folgt deinem Gesicht mit den Augen (Gesichtserkennung auf dem Handy). Gemini bekommt
  dazu alle halbe Sekunde ein kleines Bild (Live-Video), er sieht also dich und alles, was du ihm zeigst. Abschaltbar.
- **Er reagiert auf Bewegung:** Hältst du ihm etwas hin oder bewegt sich etwas vor der Kamera, schaut er hin, reißt die Augen
  auf und hüpft. Er blinzelt nur noch ab und zu.
- **Stimmen:** Im Menü „Stimmen“ (oder per Zuruf „Bluey, lerne meine Stimme“) lernt er die Stimmen der Leute zu Hause.
  Danach erkennt er, wer spricht, und nennt die Person beim Namen. Das ist eine einfache Erkennung auf dem Handy, kein
  Sicherheitsmerkmal. Gespeichert werden nur Zahlen, keine Aufnahmen.
- **Noch mehr:** Wetter am Standort des Handys („Wie wird das Wetter?“), Timer und Wecker stellen, Taschenlampe, Uhrzeit, sich Dinge merken („Merk dir …“, Menü „Notizen“),
  Witze, Rätsel und Schere-Stein-Papier mit der Kamera.
- **Recherche:** Für Aktuelles nutzt er die Google-Suche von Gemini.
- **App-Icon:** Bluey selbst.

## Neu: Weckwort, Duo, Gegenstände, Standort

- **Weckwort ohne Piepton:** Im Menü „Weckwort“ nimmst du „Hey Bluey“ drei- bis viermal auf (jede Farbe hat ihr eigenes Wort).
  Danach bleibt das Mikrofon im Schlaf **durchgehend** offen und lautlos, und das Handy vergleicht kurze Geräusche mit deinen
  Aufnahmen. Alles bleibt auf dem Handy. Mit dem Regler „Empfindlichkeit“ und dem Test siehst du, wie gut es klappt.
  Wer lieber ohne Aufnahme arbeitet, schaltet in den Einstellungen „Spracherkennung des Handys nutzen“ an (piept aber).
- **Duo-Modus:** Zwei Handys mit Bluey nebeneinander stellen, einmal in den Bluetooth-Einstellungen koppeln, dann im Menü „Duo“
  auf dem einen „Dieses Handy wartet“ und auf dem anderen „Mit Handy verbinden“ tippen. Danach unterhalten sich die beiden
  zu einem Thema (oder per Zuruf „Bluey, unterhalte dich mit dem anderen über Pizza“). Jeder spricht mit seiner Stimme. Dabei
  schauen sie zueinander, nicken, Noten und Herzen fliegen hinüber, und die Worte des anderen erscheinen an seiner Seite.
- **Er sieht Gegenstände:** Hältst du ihm etwas hin, schaut er es an (Objekterkennung auf dem Handy), staunt und hüpft.
- **Standort:** „Wo bin ich?“ und „Wie wird das Wetter?“ nutzen den Standort des Handys. Beim Aufwachen kennt er schon deinen Ort.
- **Er sagt nie „Ich bin nur ein Sprachmodell“:** Solche Sätze werden erkannt und abgeschnitten, bevor man sie hört. Stattdessen
  sagt er kurz auf Deutsch, dass er das nicht kann.
- **Stimme laut genug:** Die Lautstärke-Regelung wirkt jetzt auf die Anruf-Lautstärke, und leise Sprache wird angehoben.

## Bauen

Mit Android Studio oder, ohne PC, über GitHub Actions (Anleitung im Chat): ZIP in ein GitHub-Repository hochladen,
`.github/workflows/build.yml` anlegen, die fertige APK unter Actions → Artifacts herunterladen.

Beim ersten Start Kamera und Mikrofon erlauben und den **Gemini-API-Schlüssel** einfügen
(kostenlos bei aistudio.google.com/apikey). Er wird verschlüsselt auf dem Handy gespeichert.

## Bedienung

- **„Hey <Name>“:** aufwecken. Er schläft von selbst wieder ein, wenn 5 Minuten niemand mit ihm gesprochen hat, oder wenn du „Tschüss“ sagst.
- **Tippen:** aufwecken. **Doppeltippen:** schlafen legen
- Lautsprecher-Knopf oben rechts: Lautstärke, „Hallo sagen“
- Kachel-Knopf daneben: Verlauf, Einstellungen (Farbe, Zuruf, Kamera, Schlüssel), Stimmen, Notizen
- Kamera-Symbol unten links: grau = Kamera an, grün = er sieht dein Gesicht

## Technik

`Agent.kt` (Persönlichkeit, Stimme, Tools, Recherche) · `LiveVoice.kt` (Gemini Live per WebSocket, Mikrofon) ·
`Player.kt` (seine Stimme) · `WakeWord.kt` („Hey Bluey“) · `CameraWatcher.kt` (Kamera, Gesicht) ·
`Palette.kt` (Farben und Namen) · `FaceView.kt` (Gesicht) · `Ui.kt`, `MainActivity.kt` · `SessionStore.kt` (Verlauf) · `Settings.kt`

Modelle (in `Agent.kt` änderbar): Live `gemini-3.8-live`, Recherche `gemini-3.8-flash`.

## Datenschutz

- Gesichtserkennung bleibt auf dem Handy.
- Solange er wach ist, geht dein Ton an Google (Gemini Live). Mit „Er sieht mich“ an auch ein kleines Kamerabild pro Sekunde.
- Stimmen- und Bewegungserkennung laufen nur auf dem Handy.
- Im Schlaf hört das Handy mit Androids Spracherkennung auf „Hey <Name>“. Je nach Handy läuft das auf dem Gerät oder über Google.
- Die Kamera läuft nur, solange er wach ist und die App offen ist.

## Wenn er mal hängt

Er überwacht sich jetzt selbst: Kommt keine Verbindung zustande, hängt eine Antwort, ein Werkzeug (z. B. Recherche) oder das
Mikrofon, setzt er sich zurück. Geht die Verbindung verloren, versucht er es mehrmals neu und sagt Bescheid, wenn es nicht klappt.
Hilft das nicht: **Doppeltippen** setzt ihn immer zurück (er schläft ein), dann wecken.

## Bekannte Grenzen

- Das Aufwecken per Zuruf hängt an der Spracherkennung deines Handys. Auf manchen Handys piept sie bei jedem Neustart.
  Dann den Zuruf in den Einstellungen ausschalten und doppeltippen.
- Der Piepton der Spracherkennung wird im Schlaf stummgeschaltet (Benachrichtigungs-, System- und Medienton). Bei manchen Handys
  klappt das nicht. Dann den Zuruf in den Einstellungen ausschalten und tippen.
- Das Wetter braucht die Standort-Erlaubnis und kommt von open-meteo.com.
- Das eigene Weckwort ist eine einfache Mustererkennung. Es kennt nur die Stimmen, die es aufgenommen hat, und kann sich irren.
- Duo: Die beiden hören sich nicht gegenseitig, sie schicken sich die Sätze als Text über Bluetooth.
- Er hört dir nicht zu, solange er selbst spricht (sonst würde er sich selbst antworten).

## Lizenz

Unlicense, wie das Hauptprojekt. Die Schriften (Fredoka, IBM Plex) stehen unter der SIL OFL, siehe `licenses/`.
