# Bluey für Android

Android-Version der iPhone-App von [Bluey](../README.md). Sie spricht dasselbe Protokoll wie die iOS-App,
die Mac-Menüleisten-App muss also **nicht** geändert werden.

Ein Handy im Querformat zeigt das Blaubeer-Gesicht. Der Mac steuert Blick und Stimmung, das Handy hält die
OpenAI-Realtime-Sitzung (nur Text-Ausgabe) und nimmt das Meeting auf.

## Bauen

1. Projekt in **Android Studio** (Koala oder neuer) öffnen. Der Gradle-Wrapper wird beim Öffnen erzeugt.
2. Handy per USB anschließen (Entwickleroptionen an) und **Run** drücken.
3. Beim ersten Wecken das Mikrofon erlauben.

Mindestens Android 8.0 (API 26). Handy und Mac müssen im selben WLAN sein.

## Bedienung

- **Doppeltippen**: aufwecken / wieder schlafen legen
- **Gedrückt halten**: eine Frage stellen, loslassen = Antwort
- Lautsprecher-Knopf oben rechts: Chirp-Lautstärke, „Say hi“, Mac auswählen
- Kachel-Knopf daneben: Sessions, Transkripte, „Copy prompt for agent“, Teilen

## Entsprechung zur iOS-App

| iOS | Android |
| --- | --- |
| `Shared/GooglyLink.swift` (Network, Bonjour) | `GooglyLink.kt` (Socket) + `MacLink.kt` (NsdManager) |
| `LiveVoice.swift` (AVAudioEngine, URLSessionWebSocketTask) | `LiveVoice.kt` (AudioRecord, AudioTrack, OkHttp) |
| `ChunkRecorder.swift` (AVAudioFile, AAC) | `ChunkRecorder.kt` (MediaCodec + MediaMuxer, AAC .m4a) |
| `SessionStore.swift` | `SessionStore.kt` (JSON in `filesDir`) + `NotesSync` |
| `FaceView.swift`, `BlobShape.swift` | `FaceView.kt` (Compose Canvas) |
| `GooglyApp.swift`, `PairingView`, `SoundButton`, `BlueyAppView` | `MainActivity.kt`, `Ui.kt` |

Unterschiede: Ein Vordergrunddienst (`SessionService`) hält das Mikrofon im Hintergrund am Leben; Echo-Unterdrückung
und Rauschfilter nutzen die Android-Audioeffekte, falls das Gerät sie anbietet.

## Lizenz

Unlicense, wie das Hauptprojekt. Die Schriften (Fredoka, IBM Plex) stehen unter der SIL OFL, siehe `licenses/`.
