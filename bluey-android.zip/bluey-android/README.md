# Bluey für Android (eigenständig, mit Gemini)

Bluey ist ein reiner KI-Helfer auf dem Handy. Es wird **kein Mac und kein Desktop** gebraucht.

- **Freihändig:** Sag „Hey Bluey“ (oder „Hey Pinky“, „Hey Greeny“ …), dann wacht er auf. Du musst nichts tippen.
- **Er spricht Deutsch** (und antwortet in deiner Sprache, wenn du eine andere sprichst) mit einer süßen Stimme.
  Bluey und Greeny sind Jungs, Pinky ist ein Mädchen. Dazu erscheint seine Antwort als kleine Sprechblase.
- **Farben:** In den Einstellungen wählst du seine Farbe. Je nach Farbe heißt er anders, hört auf einen anderen Namen
  und hat eine andere Stimme:

  | Farbe | Name | Stimme |
  | --- | --- | --- |
  | Blau | Bluey | Junge (Puck) |
  | Pink | Pinky | Mädchen (Leda) |
  | Grün | Greeny | Junge (Fenrir) |
  | Lila | Purply | Mädchen (Aoede) |
  | Orange | Orangy | Mädchen (Kore) |

- **Er guckt dich an:** Die Frontkamera folgt deinem Gesicht mit den Augen (Gesichtserkennung läuft auf dem Handy).
  Alle paar Sekunden bekommt Gemini ein kleines Bild von dir, damit er dich sehen kann. Abschaltbar.
- **Recherche:** Für Aktuelles nutzt er die Google-Suche von Gemini.
- **App-Icon:** Bluey selbst.

## Bauen

Mit Android Studio oder, ohne PC, über GitHub Actions (Anleitung im Chat): ZIP in ein GitHub-Repository hochladen,
`.github/workflows/build.yml` anlegen, die fertige APK unter Actions → Artifacts herunterladen.

Beim ersten Start Kamera und Mikrofon erlauben und den **Gemini-API-Schlüssel** einfügen
(kostenlos bei aistudio.google.com/apikey). Er wird verschlüsselt auf dem Handy gespeichert.

## Bedienung

- **„Hey <Name>“:** aufwecken. Er schläft von selbst wieder ein, wenn 90 Sekunden nichts passiert, oder wenn du „Tschüss“ sagst.
- **Doppeltippen:** aufwecken / schlafen legen (wenn Zuruf nicht klappt)
- Lautsprecher-Knopf oben rechts: Lautstärke, „Hallo sagen“
- Kachel-Knopf daneben: Verlauf der Gespräche und Einstellungen (Farbe, Zuruf, Kamera, Schlüssel)
- Kamera-Symbol unten links: grau = Kamera an, grün = er sieht dein Gesicht

## Technik

`Agent.kt` (Persönlichkeit, Stimme, Tools, Recherche) · `LiveVoice.kt` (Gemini Live per WebSocket, Mikrofon) ·
`Player.kt` (seine Stimme) · `WakeWord.kt` („Hey Bluey“) · `CameraWatcher.kt` (Kamera, Gesicht) ·
`Palette.kt` (Farben und Namen) · `FaceView.kt` (Gesicht) · `Ui.kt`, `MainActivity.kt` · `SessionStore.kt` (Verlauf) · `Settings.kt`

Modelle (in `Agent.kt` änderbar): Live `gemini-3.8-live`, Recherche `gemini-3.8-flash`.

## Datenschutz

- Gesichtserkennung bleibt auf dem Handy.
- Solange er wach ist, geht dein Ton an Google (Gemini Live). Mit „Er sieht mich“ an auch alle paar Sekunden ein Kamerabild.
- Im Schlaf hört das Handy mit Androids Spracherkennung auf „Hey <Name>“. Je nach Handy läuft das auf dem Gerät oder über Google.
- Die Kamera läuft nur, solange die App offen ist.

## Bekannte Grenzen

- Das Aufwecken per Zuruf hängt an der Spracherkennung deines Handys. Auf manchen Handys piept sie bei jedem Neustart.
  Dann den Zuruf in den Einstellungen ausschalten und doppeltippen.
- Er hört dir nicht zu, solange er selbst spricht (sonst würde er sich selbst antworten).

## Lizenz

Unlicense, wie das Hauptprojekt. Die Schriften (Fredoka, IBM Plex) stehen unter der SIL OFL, siehe `licenses/`.
