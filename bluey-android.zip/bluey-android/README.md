# Bluey für Android (eigenständig)

Bluey ist hier ein reiner KI-Helfer auf dem Handy. Es wird **kein Mac und kein Desktop** gebraucht.

- **Er guckt dich immer an:** Die Frontkamera läuft, solange die App offen ist. Eine Gesichtserkennung (ML Kit, auf dem Gerät)
  steuert seine Augen, er schaut zu dir, und wenn du lächelst, freut er sich.
- **Er sieht dich, wenn du fragst:** Bei jeder Frage geht ein frisches Foto von dir mit an die KI. Abschaltbar in den Einstellungen.
- **Er hört zu:** Das Mikrofon ist an, solange er wach ist. Er bleibt still, bis du fragst.
- **Er antwortet als Sprechblase** (eine kurze Zeile) mit einem kleinen Chirp, nie laut gesprochen.
- **Er kann recherchieren:** Für Aktuelles und Fakten nutzt er die Websuche von OpenAI und merkt sich den Bericht im Verlauf.

## Bauen und starten

1. Ordner in **Android Studio** (Koala oder neuer) öffnen. Der Gradle-Wrapper wird beim Öffnen erzeugt.
2. Handy per USB anschließen (Entwickleroptionen an), **Run** drücken. Mindestens Android 8.0 (API 26).
3. Kamera und Mikrofon erlauben, dann den **OpenAI-API-Key** einfügen (wird verschlüsselt auf dem Handy gespeichert).

## Bedienung

- **Doppeltippen:** aufwecken / schlafen legen
- **Gedrückt halten:** Frage stellen, loslassen = Antwort
- Lautsprecher-Knopf oben rechts: Chirp-Lautstärke, „Say hi“
- Kachel-Knopf daneben: Verlauf (Transkripte, Teilen) und Einstellungen (Key, „He sees me when I ask“)
- Kleines Kamera-Symbol unten links: grau = Kamera an, grün = er sieht dein Gesicht

## Datenschutz

Das Gesichts-Tracking läuft nur auf dem Handy. Bilder gehen nur dann an OpenAI, wenn du eine Frage stellst und
„He sees me when I ask“ an ist. Audio geht an OpenAI, solange er wach ist (nötig für die Transkription).
Die Kamera läuft nur, solange die App im Vordergrund ist.

## Was gegenüber der Mac-Version wegfällt

Bildschirm lesen, zeigen, klicken, tippen, Meeting-Notizen mit Sprechertrennung (die kamen vom Mac) und der große Cursor.
Das Gesprächsprotokoll bleibt auf dem Handy.

## Dateien

`Agent.kt` (Persönlichkeit, Tools, Recherche) · `LiveVoice.kt` (Realtime-Sitzung, Mikrofon, Chirp) ·
`CameraWatcher.kt` (Kamera, Gesicht, Foto) · `FaceView.kt` (Gesicht) · `Ui.kt`, `MainActivity.kt` (Oberfläche) ·
`SessionStore.kt` (Verlauf) · `Settings.kt` (Key)

## Lizenz

Unlicense, wie das Hauptprojekt. Die Schriften (Fredoka, IBM Plex) stehen unter der SIL OFL, siehe `licenses/`.
