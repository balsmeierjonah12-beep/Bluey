package app.bluey.android

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Plays his voice: 24 kHz 16-bit mono PCM chunks from Gemini, one after another, with a loudness reading for his mouth. */
class Player {
    companion object { const val RATE = 24_000 }

    private var track: AudioTrack? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var written = 0L
    @Volatile var level = 0.0; private set

    var gain = 1f
        set(value) { field = value; track?.setVolume(value) }

    /** True while his voice is queued or still coming out of the speaker. */
    val busy: Boolean
        get() {
            if (!running) return false
            val t = track ?: return false
            return queue.isNotEmpty() || written - t.playbackHeadPosition > RATE / 10
        }

    private fun build(): AudioTrack {
        val minBuffer = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(minBuffer * 2, RATE))  // about half a second
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.setVolume(gain)
        t.play()
        return t
    }

    fun start() {
        if (running) return
        track = build()
        written = 0
        running = true
        thread = Thread {
            while (running) {
                val chunk = queue.poll(100, TimeUnit.MILLISECONDS)
                if (chunk == null) { level = 0.0; continue }
                var offset = 0
                while (offset < chunk.size && running) {
                    val n = min(960, chunk.size - offset)  // 20 ms pieces, so the mouth can follow along
                    var sum = 0.0
                    var i = offset
                    while (i + 1 < offset + n) {
                        val v = ((chunk[i + 1].toInt() shl 8) or (chunk[i].toInt() and 0xFF)).toShort().toInt() / 32768.0
                        sum += v * v
                        i += 2
                    }
                    level = min(1.0, sqrt(sum / (n / 2)) * 5.0)
                    val t = track ?: break
                    val w = t.write(chunk, offset, n)
                    if (w <= 0) break
                    written += w / 2
                    offset += w
                }
            }
        }.apply { isDaemon = true; start() }
    }

    fun write(pcm: ByteArray) { if (running) queue.offer(pcm) }

    /** He was interrupted: drop everything that's still queued. */
    fun clear() {
        if (!running) return
        queue.clear()
        val old = track
        track = build()
        written = 0
        old?.let { try { it.pause(); it.flush() } catch (_: Exception) {}; it.release() }
        level = 0.0
    }

    fun stop() {
        running = false
        queue.clear()
        try { thread?.join(300) } catch (_: Exception) {}
        thread = null
        track?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        track = null
        level = 0.0
    }
}
