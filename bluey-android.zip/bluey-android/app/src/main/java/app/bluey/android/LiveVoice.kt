package app.bluey.android

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * A live, hands-free conversation with Google's Gemini Live API. Once he's awake the mic streams to Gemini,
 * which notices when you talk, and he answers out loud with the voice of his color. His words also appear
 * as a speech bubble. Every few seconds he gets a small picture of you from the front camera.
 */
class LiveVoice(context: Context, private val settings: Settings, private val camera: CameraWatcher) {
    enum class State { ASLEEP, WAKING, LISTENING, ASKING, THINKING, SPEAKING }

    companion object {
        const val MIC_RATE = 16_000
        private const val TAG = "BlueyLive"
        private const val IDLE_SLEEP_MS = 90_000L
        private const val VIDEO_EVERY_MS = 4_000L
    }

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("bluey", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()
    private val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val player = Player()

    var state by mutableStateOf(State.ASLEEP); private set

    /** Asks for the microphone permission; calls back with whether it was granted. */
    var requestMic: (((Boolean) -> Unit) -> Unit)? = null
    /** Called when he needs a Gemini key before he can wake up. */
    var onNeedKey: (() -> Unit)? = null
    var onCaption: ((String, Boolean) -> Unit)? = null
    var onStateChange: ((State) -> Unit)? = null
    var onSessionStart: (() -> Unit)? = null
    var onSessionEnd: (() -> Unit)? = null
    var onUserTurn: ((String, Boolean) -> Unit)? = null
    var onUserWords: ((String, String, Boolean) -> Unit)? = null
    var onReply: ((String) -> Unit)? = null
    var onReport: ((String) -> Unit)? = null

    /** Loudness of his voice right now, 0…1 (moves his mouth). */
    val level: Double get() = player.level

    var volume: Float
        get() = prefs.getFloat("volume", 1f)
        set(v) { prefs.edit().putFloat("volume", v).apply(); player.gain = v }

    private var wantAwake = false
    private var reconnecting = false
    private var socket: WebSocket? = null
    private var ready = false
    private var everReady = false
    private var reconnectAttempts = 0
    private var resumeHandle: String? = null
    private var transcript = StringBuilder()
    private var userText = StringBuilder()
    private var userItem: String? = null
    private var userCounter = 0
    private var responseActive = false
    private var sleepAfterReply = false
    private var toolsRunning = 0
    @Volatile private var lastActivity = 0L

    private fun changeState(new: State) {
        if (new == state) return
        state = new
        onStateChange?.invoke(new)
    }

    // Wake and sleep

    fun toggle() { if (state == State.ASLEEP) wake() else sleep() }

    fun wake() {
        if (state != State.ASLEEP) return
        wantAwake = true
        changeState(State.WAKING)
        val ask = requestMic
        if (ask == null) { fail(); return }
        ask { granted ->
            main.post {
                if (!granted) {
                    onCaption?.invoke("Ich brauche das Mikrofon. Erlaube es in den Handy-Einstellungen.", true)
                    fail(); return@post
                }
                if (!settings.hasKey) {
                    onCaption?.invoke("Ich brauche zuerst einen Gemini-Schlüssel. Trag ihn in den Einstellungen ein.", true)
                    onNeedKey?.invoke()
                    fail(); return@post
                }
                connect(settings.apiKey)
            }
        }
    }

    private fun fail() { wantAwake = false; changeState(State.ASLEEP) }

    fun sleep() {
        val wasRunning = wantAwake || socket != null
        wantAwake = false
        reconnecting = false
        main.removeCallbacks(videoTick)
        main.removeCallbacks(idleTick)
        if (wasRunning) onSessionEnd?.invoke()
        val old = socket
        socket = null
        old?.close(1000, null)
        stopAudio()
        transcript = StringBuilder()
        userText = StringBuilder()
        userItem = null
        responseActive = false
        sleepAfterReply = false
        toolsRunning = 0
        ready = false
        everReady = false
        resumeHandle = null
        changeState(State.ASLEEP)
    }

    /** Makes him say a quick hi (for checking the volume). */
    fun sayHi() {
        if (!ready) { wake(); return }
        sendText("Sag ganz kurz hallo, höchstens vier Wörter.")
    }

    // Connection

    private fun connect(key: String) {
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ready = false
        val ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(Agent.setup(settings.skin, resumeHandle).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) = incoming(webSocket, text)
            // Gemini sends its JSON as binary frames.
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = incoming(webSocket, bytes.utf8())
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(code, reason)
                dropped(webSocket, code, reason)
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = dropped(webSocket, code, reason)
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                dropped(webSocket, response?.code ?: 0, t.message ?: "")
            }
        })
        socket = ws
    }

    private fun incoming(webSocket: WebSocket, raw: String) {
        val event = try { JSONObject(raw) } catch (_: Exception) { return }
        main.post { if (webSocket === socket) handle(event) }
    }

    private fun dropped(webSocket: WebSocket, code: Int, reason: String) {
        Log.d(TAG, "closed: $code $reason")
        main.post {
            if (webSocket !== socket) return@post
            val keyProblem = code == 401 || code == 403 || reason.contains("API key", true) || reason.contains("API_KEY")
            when {
                keyProblem -> {
                    onCaption?.invoke("Gemini hat meinen Schlüssel abgelehnt. Prüf ihn in den Einstellungen.", true)
                    onNeedKey?.invoke()
                    sleep()
                }
                !everReady -> {
                    onCaption?.invoke("Gemini hat die Verbindung beendet: ${reason.take(140)}", true)
                    sleep()
                }
                wantAwake -> reconnect()
                else -> sleep()
            }
        }
    }

    /** The connection dropped mid-session: try again shortly and continue where we were. */
    private fun reconnect() {
        socket = null
        ready = false
        responseActive = false
        toolsRunning = 0
        if (!wantAwake) return
        reconnecting = true
        val delay = min(30_000L, 1500L + reconnectAttempts * 3000L)
        reconnectAttempts += 1
        main.postDelayed({
            if (wantAwake && socket == null) connect(settings.apiKey)
        }, delay)
    }

    private fun send(message: JSONObject) { socket?.send(message.toString()) }

    private fun sendText(text: String) =
        send(JSONObject().put("realtimeInput", JSONObject().put("text", text)))

    private fun sendVideo(base64Jpeg: String) =
        send(JSONObject().put("realtimeInput", JSONObject().put("video",
            JSONObject().put("data", base64Jpeg).put("mimeType", "image/jpeg"))))

    private fun sendAudio(pcm: ShortArray) {
        if (!ready) return
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            bytes[2 * i] = (pcm[i].toInt() and 0xFF).toByte()
            bytes[2 * i + 1] = ((pcm[i].toInt() shr 8) and 0xFF).toByte()
        }
        socket?.send(JSONObject().put("realtimeInput", JSONObject().put("audio",
            JSONObject().put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("mimeType", "audio/pcm;rate=16000"))).toString())
    }

    // Messages from Gemini

    private fun handle(event: JSONObject) {
        when {
            event.has("setupComplete") -> onReady()
            event.has("serverContent") -> content(event.getJSONObject("serverContent"))
            event.has("toolCall") -> {
                val calls = event.getJSONObject("toolCall").optJSONArray("functionCalls") ?: JSONArray()
                runTools((0 until calls.length()).map { calls.getJSONObject(it) })
            }
            event.has("sessionResumptionUpdate") -> {
                val update = event.getJSONObject("sessionResumptionUpdate")
                val handle = update.optString("newHandle", "")
                if (update.optBoolean("resumable", false) && handle.isNotEmpty()) resumeHandle = handle
            }
            event.has("goAway") -> {
                // The server will hang up soon: reconnect right away, resuming the same conversation.
                val old = socket
                socket = null
                old?.close(1000, "goAway")
                reconnect()
            }
        }
    }

    private fun onReady() {
        ready = true
        everReady = true
        reconnectAttempts = 0
        lastActivity = System.currentTimeMillis()
        if (reconnecting) {
            reconnecting = false
            changeState(State.LISTENING)
            return
        }
        try {
            startAudio()
        } catch (e: Exception) {
            onCaption?.invoke("Ich konnte das Mikrofon nicht starten: ${e.message}", true)
            sleep(); return
        }
        onSessionStart?.invoke()
        changeState(State.LISTENING)
        sendText("Der Nutzer hat dich gerade geweckt. Begrüße ihn ganz kurz, höchstens vier Wörter.")
        main.removeCallbacks(videoTick); main.postDelayed(videoTick, 700)
        main.removeCallbacks(idleTick); main.postDelayed(idleTick, 5_000)
    }

    private fun content(c: JSONObject) {
        // What you said (Gemini's transcript of your voice).
        c.optJSONObject("inputTranscription")?.optString("text", "")?.takeIf { it.isNotEmpty() }?.let { piece ->
            lastActivity = System.currentTimeMillis()
            var item = userItem
            if (item == null) {
                userCounter += 1
                item = "u$userCounter"
                userItem = item
                userText = StringBuilder()
                onUserTurn?.invoke(item, true)
            }
            userText.append(piece)
            onUserWords?.invoke(item, userText.toString(), true)
            if (state == State.LISTENING) changeState(State.ASKING)
        }
        // His voice.
        c.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data", "") ?: ""
                if (data.isEmpty()) continue
                responseActive = true
                lastActivity = System.currentTimeMillis()
                if (state != State.SPEAKING) changeState(State.SPEAKING)
                player.write(Base64.decode(data, Base64.DEFAULT))
            }
        }
        // What he said (the transcript of his voice, shown as the speech bubble).
        c.optJSONObject("outputTranscription")?.optString("text", "")?.takeIf { it.isNotEmpty() }?.let { piece ->
            responseActive = true
            lastActivity = System.currentTimeMillis()
            transcript.append(piece)
            if (state != State.SPEAKING) changeState(State.SPEAKING)
            onCaption?.invoke(transcript.toString().trim(), false)
        }
        if (c.optBoolean("interrupted", false)) {
            player.clear()
            transcript = StringBuilder()
            responseActive = false
        }
        if (c.optBoolean("turnComplete", false)) {
            responseActive = false
            userItem = null
            val said = transcript.toString().trim()
            if (said.isNotEmpty()) {
                onCaption?.invoke(said, true)
                onReply?.invoke(said)
            }
            transcript = StringBuilder()
            main.postDelayed({ finishIfQuiet() }, 200)
        }
    }

    private fun runTools(calls: List<JSONObject>) {
        if (calls.isEmpty()) return
        var remaining = calls.size
        toolsRunning += 1
        if (state != State.SPEAKING) changeState(State.THINKING)
        val responses = JSONArray()
        for (call in calls) {
            val id = call.optString("id")
            val name = call.optString("name")
            val arguments = call.optJSONObject("args")?.toString() ?: "{}"
            if (name == "go_to_sleep") sleepAfterReply = true
            Agent.runTool(settings.apiKey, name, arguments) { output ->
                main.post {
                    if (socket == null) return@post
                    if (name == "web_research" && !output.startsWith("The research")) onReport?.invoke(output)
                    responses.put(JSONObject().put("id", id).put("name", name)
                        .put("response", JSONObject().put("result", output)))
                    remaining -= 1
                    if (remaining == 0) {
                        toolsRunning = max(0, toolsRunning - 1)
                        send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", responses)))
                    }
                }
            }
        }
    }

    private fun finishIfQuiet() {
        if (state == State.ASLEEP) return
        if (responseActive || toolsRunning != 0) return
        if (player.busy) { main.postDelayed({ finishIfQuiet() }, 200); return }
        if (sleepAfterReply) { sleep(); return }
        if (state == State.SPEAKING || state == State.THINKING || state == State.ASKING) changeState(State.LISTENING)
    }

    /** Every few seconds: a small picture of you, so he can see you while you talk. */
    private val videoTick = object : Runnable {
        override fun run() {
            if (!wantAwake) return
            if (ready && settings.seeMe && camera.running) {
                camera.snapshot { photo -> main.post { if (photo != null && ready) sendVideo(photo) } }
            }
            main.postDelayed(this, VIDEO_EVERY_MS)
        }
    }

    /** Nobody has said anything for a while: back to sleep (and listening for the wake word). */
    private val idleTick = object : Runnable {
        override fun run() {
            if (!wantAwake) return
            if (System.currentTimeMillis() - lastActivity > IDLE_SLEEP_MS && !player.busy && toolsRunning == 0) { sleep(); return }
            main.postDelayed(this, 5_000)
        }
    }

    // Audio in: the mic, as 16 kHz 16-bit mono PCM

    private var record: AudioRecord? = null
    private var micThread: Thread? = null
    @Volatile private var micRunning = false
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var savedMode = AudioManager.MODE_NORMAL

    @Suppress("DEPRECATION")
    private fun routeToSpeaker() {
        savedMode = audio.mode
        audio.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT >= 31) {
            val devices = audio.availableCommunicationDevices
            val headset = setOf(AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET)
            if (devices.none { it.type in headset }) {
                devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }?.let { audio.setCommunicationDevice(it) }
            }
        } else {
            if (!audio.isWiredHeadsetOn && !audio.isBluetoothScoOn) audio.isSpeakerphoneOn = true
        }
    }

    @Suppress("DEPRECATION")
    private fun restoreRoute() {
        if (Build.VERSION.SDK_INT >= 31) {
            audio.clearCommunicationDevice()
        } else {
            audio.isSpeakerphoneOn = false
        }
        audio.mode = savedMode
    }

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        if (micRunning) return
        var rec: AudioRecord? = null
        var rate = MIC_RATE
        for (candidate in intArrayOf(16_000, 48_000, 44_100, 24_000)) {
            val minBuf = AudioRecord.getMinBufferSize(candidate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) continue
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, candidate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf * 2, candidate / 5 * 2))
            if (r.state == AudioRecord.STATE_INITIALIZED) { rec = r; rate = candidate; break } else r.release()
        }
        val r = rec ?: throw IllegalStateException("kein Mikrofon verfügbar")
        routeToSpeaker()
        player.gain = volume
        player.start()
        record = r
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.enabled = true }
        r.startRecording()
        micRunning = true
        val ratio = rate.toDouble() / MIC_RATE
        micThread = Thread {
            val frame = ShortArray(rate / 10)  // 100 ms
            var carry = 0.0
            var lastBusy = 0L
            while (micRunning) {
                val n = r.read(frame, 0, frame.size)
                if (n <= 0) continue
                val out: ShortArray
                if (rate == MIC_RATE) {
                    out = frame.copyOf(n)
                } else {
                    // Linear resampling to 16 kHz.
                    val list = ShortArray(((n + 1) / ratio).toInt() + 2)
                    var count = 0
                    var pos = carry
                    while (pos < n) {
                        val i = pos.toInt()
                        val a = frame[i]
                        val b = if (i + 1 < n) frame[i + 1] else a
                        val frac = pos - i
                        if (count < list.size) list[count++] = (a + (b - a) * frac).toInt().toShort()
                        pos += ratio
                    }
                    carry = pos - n
                    out = list.copyOf(count)
                }
                if (out.isEmpty()) continue
                // While his voice comes out of the speaker the mic stays quiet, so he never answers himself.
                val now = SystemClock.elapsedRealtime()
                if (player.busy) lastBusy = now
                else if (now - lastBusy > 350) sendAudio(out)
            }
        }.apply { isDaemon = true; start() }
    }

    private fun stopAudio() {
        val wasRunning = micRunning
        micRunning = false
        try { micThread?.join(300) } catch (_: Exception) {}
        micThread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
        aec?.release(); aec = null
        ns?.release(); ns = null
        player.stop()
        if (wasRunning) restoreRoute()
    }
}
