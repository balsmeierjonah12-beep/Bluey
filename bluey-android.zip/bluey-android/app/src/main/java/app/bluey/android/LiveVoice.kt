package app.bluey.android

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * A live session with OpenAI's Realtime API, running on the phone. Once he's awake the mic is on the whole
 * time, so everything you say becomes context, but he stays quiet until you hold the screen and ask.
 * Replies are text (speech bubbles on the Mac) with a little cartoon chirp here. Tools run on the Mac.
 */
class LiveVoice(context: Context, val recorder: ChunkRecorder) {
    enum class State { ASLEEP, WAKING, LISTENING, ASKING, THINKING, SPEAKING }

    companion object {
        const val MODEL = "gpt-realtime-2.1"
        const val WIRE_RATE = 24_000
        private const val TAG = "BlueyRealtime"
    }

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("bluey", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()

    var state by mutableStateOf(State.ASLEEP); private set

    /** Asks the Mac for a short-lived key. Calls back with null on failure. */
    var requestToken: (((String?) -> Unit) -> Unit)? = null
    /** Runs a tool on the Mac: (name, JSON arguments) → (output text, optional JPEG base64). */
    var runTool: ((String, String, (String, String?) -> Unit) -> Unit)? = null
    /** Asks for the microphone permission; calls back with whether it was granted. */
    var requestMic: (((Boolean) -> Unit) -> Unit)? = null
    var onCaption: ((String, Boolean) -> Unit)? = null
    var onStateChange: ((State) -> Unit)? = null
    var onSessionStart: (() -> Unit)? = null
    var onSessionEnd: (() -> Unit)? = null
    var onUserTurn: ((String, Boolean) -> Unit)? = null
    var onUserWords: ((String, String, Boolean) -> Unit)? = null
    var onReply: ((String) -> Unit)? = null
    var onReport: ((String) -> Unit)? = null
    var resumeContext: (() -> String?)? = null

    @Volatile var level = 0.0; private set

    var volume: Float
        get() = prefs.getFloat("volume", 1f)
        set(v) { prefs.edit().putFloat("volume", v).apply(); chirpTrack?.setVolume(v) }

    private var wantAwake = false
    private var reconnecting = false
    private var socket: WebSocket? = null
    private var transcript = StringBuilder()
    private var pendingChirps = 0
    private var responseActive = false
    private var sleepAfterReply = false
    private var holding = false
    private var askWhenReady = false
    private var chirpedThisResponse = false
    private val askedItems = HashSet<String>()
    private var awaitingQuestion = false
    private var toolsRunning = 0

    private fun setState(new: State) {
        if (new == state) return
        state = new
        onStateChange?.invoke(new)
    }

    // Wake and sleep

    fun toggle() { if (state == State.ASLEEP) wake() else sleep() }

    fun wake() {
        if (state != State.ASLEEP) return
        wantAwake = true
        setState(State.WAKING)
        val ask = requestMic
        if (ask == null) { fail(); return }
        ask { granted ->
            main.post {
                if (!granted) {
                    onCaption?.invoke("I need the microphone. Turn it on for Bluey in the phone's Settings.", true)
                    fail(); return@post
                }
                val tokenRequest = requestToken
                if (tokenRequest == null) { fail(); return@post }
                tokenRequest { token ->
                    main.post {
                        if (state != State.WAKING) return@post
                        if (token == null) fail() else connect(token)
                    }
                }
            }
        }
    }

    private fun fail() { wantAwake = false; setState(State.ASLEEP) }

    fun sleep() {
        val wasRunning = wantAwake || socket != null
        wantAwake = false
        reconnecting = false
        recorder.finish()
        if (wasRunning) onSessionEnd?.invoke()
        askedItems.clear()
        awaitingQuestion = false
        socket?.close(1000, null)
        socket = null
        stopAudio()
        transcript = StringBuilder()
        pendingChirps = 0
        responseActive = false
        sleepAfterReply = false
        holding = false
        askWhenReady = false
        toolsRunning = 0
        level = 0.0
        setState(State.ASLEEP)
    }

    /** Says a quick hi (for checking the chirp volume). */
    fun sayHi() {
        if (socket == null) { wake(); return }
        send(JSONObject().put("type", "response.create")
            .put("response", JSONObject().put("instructions", "Reply with a quick, cheerful hi in under eight words.")))
    }

    // Hold to ask

    fun beginAsk() {
        holding = true
        onCaption?.invoke("", false)
        if (state == State.ASLEEP) { wake(); return }
        if (socket == null) return
        if (state == State.LISTENING || state == State.SPEAKING) setState(State.ASKING)
    }

    fun endAsk() {
        if (!holding) return
        holding = false
        if (socket == null || state == State.WAKING) { askWhenReady = true; return }
        ask()
    }

    private fun ask() {
        askWhenReady = false
        setState(State.THINKING)
        awaitingQuestion = true
        send(JSONObject().put("type", "input_audio_buffer.commit"))
        send(JSONObject().put("type", "response.create"))
    }

    // Connection

    private fun connect(token: String) {
        val request = Request.Builder()
            .url("wss://api.openai.com/v1/realtime?model=$MODEL")
            .header("Authorization", "Bearer $token")
            .build()
        lateinit var ws: WebSocket
        ws = http.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                val event = try { JSONObject(text) } catch (_: Exception) { return }
                main.post { if (webSocket === socket) handle(event) }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { closed(webSocket, t.message) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { closed(webSocket, reason) }
        })
        socket = ws

        if (reconnecting) {
            reconnecting = false
            val context = resumeContext?.invoke()
            if (!context.isNullOrEmpty()) {
                send(JSONObject().put("type", "conversation.item.create").put("item", JSONObject()
                    .put("type", "message").put("role", "user")
                    .put("content", JSONArray().put(JSONObject().put("type", "input_text")
                        .put("text", "(Context: what I said earlier in this session, from my notes. Don't reply to this.)\n$context")))))
            }
            if (askWhenReady) ask() else setState(if (holding) State.ASKING else State.LISTENING)
            return
        }
        try {
            startAudio()
        } catch (e: Exception) {
            onCaption?.invoke("I couldn't start the microphone: ${e.message}", true)
            sleep(); return
        }
        onSessionStart?.invoke()
        chirp(2)
        if (askWhenReady) ask() else setState(if (holding) State.ASKING else State.LISTENING)
    }

    private fun closed(webSocket: WebSocket, reason: String?) {
        Log.d(TAG, "closed: $reason")
        main.post {
            if (webSocket !== socket) return@post
            if (wantAwake) reconnect() else sleep()
        }
    }

    /** The connection dropped mid-session: get a new key and carry on, keeping the mic and recording running. */
    private fun reconnect(attempt: Int = 0) {
        socket = null
        responseActive = false
        toolsRunning = 0
        val tokenRequest = requestToken
        if (!wantAwake || tokenRequest == null) return
        reconnecting = true
        tokenRequest { token ->
            main.post {
                if (!wantAwake || socket != null) return@post
                if (token != null) connect(token)
                else main.postDelayed({ reconnect(attempt + 1) }, min(30_000L, 2000L + attempt * 3000L))
            }
        }
    }

    private fun send(event: JSONObject) {
        socket?.send(event.toString())
    }

    // Events

    private fun handle(event: JSONObject) {
        when (event.optString("type")) {
            "response.created" -> {
                responseActive = true
                transcript = StringBuilder()
                chirpedThisResponse = false
            }
            "response.output_text.delta", "response.output_audio_transcript.delta" -> {
                val delta = event.optString("delta", "")
                if (delta.isNotEmpty()) {
                    transcript.append(delta)
                    if (!chirpedThisResponse && transcript.isNotBlank()) {
                        chirpedThisResponse = true
                        setState(State.SPEAKING)
                        chirp(transcript.trim().split(Regex("\\s+")).size.coerceIn(3, 5))
                    }
                    onCaption?.invoke(transcript.toString(), false)
                }
            }
            "input_audio_buffer.committed" -> {
                val item = event.optString("item_id", "")
                if (item.isNotEmpty()) {
                    val asked = holding || awaitingQuestion
                    if (asked) askedItems.add(item)
                    if (awaitingQuestion && !holding) awaitingQuestion = false
                    onUserTurn?.invoke(item, asked)
                }
            }
            "conversation.item.input_audio_transcription.completed" -> {
                val item = event.optString("item_id", "")
                if (item.isNotEmpty() && event.has("transcript")) {
                    onUserWords?.invoke(item, event.getString("transcript"), item in askedItems)
                }
            }
            "response.done" -> {
                responseActive = false
                if (transcript.isNotEmpty()) {
                    onCaption?.invoke(transcript.toString(), true)
                    onReply?.invoke(transcript.toString())
                }
                val output = event.optJSONObject("response")?.optJSONArray("output") ?: JSONArray()
                val calls = (0 until output.length()).map { output.getJSONObject(it) }
                    .filter { it.optString("type") == "function_call" }
                if (calls.isNotEmpty()) {
                    if (state != State.SPEAKING) setState(State.THINKING)
                    runTools(calls)
                }
                finishIfQuiet()
            }
            "error" -> {
                val error = event.optJSONObject("error")
                if (error?.optString("code") == "input_audio_buffer_commit_empty") awaitingQuestion = false
                Log.w(TAG, "error: ${error?.optString("message")}")
            }
        }
    }

    private fun runTools(calls: List<JSONObject>) {
        var remaining = calls.size
        toolsRunning += 1
        val images = ArrayList<String>()
        for (call in calls) {
            val name = call.optString("name")
            val callID = call.optString("call_id")
            val arguments = call.optString("arguments", "{}")
            if (name == "go_to_sleep") sleepAfterReply = true
            val finish: (String, String?) -> Unit = { output, image ->
                main.post {
                    if (socket == null) return@post
                    val marker = "\n---REPORT---\n"
                    if (name == "web_research" && output.contains(marker)) {
                        onReport?.invoke(output.substringAfter(marker))
                    }
                    send(JSONObject().put("type", "conversation.item.create").put("item", JSONObject()
                        .put("type", "function_call_output").put("call_id", callID).put("output", output)))
                    if (image != null) images.add(image)
                    remaining -= 1
                    if (remaining == 0) {
                        toolsRunning = max(0, toolsRunning - 1)
                        for (img in images) {
                            send(JSONObject().put("type", "conversation.item.create").put("item", JSONObject()
                                .put("type", "message").put("role", "user")
                                .put("content", JSONArray().put(JSONObject().put("type", "input_image")
                                    .put("image_url", "data:image/jpeg;base64,$img")))))
                        }
                        send(JSONObject().put("type", "response.create"))
                    }
                }
            }
            val run = runTool
            if (run != null) run(name, arguments, finish) else finish("The Mac isn't connected.", null)
        }
    }

    private fun finishIfQuiet() {
        if (pendingChirps != 0 || responseActive || toolsRunning != 0) return
        if (sleepAfterReply) { sleep(); return }
        if (state == State.SPEAKING || state == State.THINKING) setState(if (holding) State.ASKING else State.LISTENING)
    }

    // Audio in: the mic, as 24 kHz 16-bit mono PCM

    private var record: AudioRecord? = null
    private var micThread: Thread? = null
    @Volatile private var micRunning = false
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        if (micRunning) return
        var rec: AudioRecord? = null
        var rate = WIRE_RATE
        for (candidate in intArrayOf(24_000, 48_000, 44_100, 16_000)) {
            val minBuf = AudioRecord.getMinBufferSize(candidate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) continue
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, candidate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf * 2, candidate / 5 * 2))
            if (r.state == AudioRecord.STATE_INITIALIZED) { rec = r; rate = candidate; break } else r.release()
        }
        val r = rec ?: throw IllegalStateException("no usable microphone")
        record = r
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.enabled = true }
        r.startRecording()
        micRunning = true
        val ratio = rate.toDouble() / WIRE_RATE
        micThread = Thread {
            val frame = ShortArray(rate / 10)  // 100 ms
            var carry = 0.0
            var last = 0.toShort()
            while (micRunning) {
                val n = r.read(frame, 0, frame.size)
                if (n <= 0) continue
                val out: ShortArray
                if (rate == WIRE_RATE) {
                    out = frame.copyOf(n)
                } else {
                    // Linear resampling to 24 kHz.
                    val list = ShortArray(((n + 1) / ratio).toInt() + 2)
                    var count = 0
                    var pos = carry
                    while (pos < n) {
                        val i = pos.toInt()
                        val a = frame[i]
                        val b = if (i + 1 < n) frame[i + 1] else a
                        val frac = pos - i
                        if (count < list.size) list[count++] = (a + (b - a) * frac).toInt().toShort()
                        pos += ratio
                    }
                    carry = pos - n
                    last = frame[n - 1]
                    out = list.copyOf(count)
                }
                if (out.isEmpty()) continue
                recorder.append(out, out.size)
                sendMic(out)
            }
        }.apply { isDaemon = true; start() }
    }

    private fun sendMic(pcm: ShortArray) {
        val ws = socket ?: return
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            bytes[2 * i] = (pcm[i].toInt() and 0xFF).toByte()
            bytes[2 * i + 1] = ((pcm[i].toInt() shr 8) and 0xFF).toByte()
        }
        ws.send(JSONObject().put("type", "input_audio_buffer.append")
            .put("audio", Base64.encodeToString(bytes, Base64.NO_WRAP)).toString())
    }

    private fun stopAudio() {
        micRunning = false
        try { micThread?.join(300) } catch (_: Exception) {}
        micThread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
        aec?.release(); aec = null
        ns?.release(); ns = null
        chirpTrack?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        chirpTrack = null
    }

    // Audio out: a tiny cartoon chirp, a few soft bell-like notes from a happy pentatonic scale

    private var chirpTrack: AudioTrack? = null
    private val levelTick = object : Runnable {
        override fun run() {
            val track = chirpTrack
            val amps = chirpAmps
            if (track == null || amps.isEmpty() || pendingChirps == 0) { level = 0.0; return }
            val i = (track.playbackHeadPosition / 512).coerceIn(0, amps.size - 1)
            level = min(1.0, amps[i] * 5.0)
            main.postDelayed(this, 30)
        }
    }
    private var chirpAmps = FloatArray(0)

    private fun chirp(syllables: Int) {
        if (!micRunning) return
        val rate = WIRE_RATE.toDouble()
        val scale = doubleArrayOf(1046.5, 1174.7, 1318.5, 1568.0, 1760.0, 2093.0, 2349.3, 2637.0)
        var index = Random.nextInt(1, 4)
        val samples = ArrayList<Float>()
        for (i in 0 until syllables) {
            if (i > 0) index = (index + listOf(-1, 1, 1, 2).random()).coerceIn(0, scale.size - 1)
            val note = scale[index] * 0.5
            val duration = if (i == syllables - 1) 0.13 else Random.nextDouble(0.07, 0.09)
            val count = (duration * rate).toInt()
            var phase = 0.0
            for (n in 0 until count) {
                val time = n / rate
                val t = n.toDouble() / count
                val scoop = 1 - 0.18 * exp(-time / 0.012)
                val wobble = if (i == syllables - 1) 1 + 0.012 * sin(time * 2 * Math.PI * 18) else 1.0
                phase += 2 * Math.PI * note * scoop * wobble / rate
                val attack = min(1.0, time / 0.006)
                val envelope = attack * exp(-t * 3.2) * (1 - t.pow(6))
                val wave = sin(phase) + 0.12 * sin(2 * phase)
                samples.add((wave * envelope * 0.26).toFloat())
            }
            repeat((rate * 0.028).toInt()) { samples.add(0f) }
        }
        val pcm = ShortArray(samples.size) { (samples[it].coerceIn(-1f, 1f) * 32767).toInt().toShort() }
        chirpAmps = FloatArray(pcm.size / 512 + 1) { w ->
            var sum = 0f; var c = 0
            for (k in w * 512 until min(pcm.size, (w + 1) * 512)) { val v = samples[k]; sum += v * v; c++ }
            if (c == 0) 0f else sqrt(sum / c)
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(WIRE_RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(pcm, 0, pcm.size)
        track.setVolume(volume)
        track.setNotificationMarkerPosition(max(1, pcm.size - 1))
        pendingChirps += 1
        track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack) {
                try { t.release() } catch (_: Exception) {}
                if (chirpTrack === t) chirpTrack = null
                pendingChirps = max(0, pendingChirps - 1)
                if (pendingChirps == 0) level = 0.0
                finishIfQuiet()
            }
            override fun onPeriodicNotification(t: AudioTrack) {}
        }, main)
        chirpTrack = track
        track.play()
        main.removeCallbacks(levelTick)
        main.post(levelTick)
    }
}
