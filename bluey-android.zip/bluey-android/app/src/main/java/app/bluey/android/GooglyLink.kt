package app.bluey.android

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedInputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/** Bonjour service name shared with the Mac app. */
const val GOOGLY_SERVICE_TYPE = "_googly._tcp."

enum class Mood(val raw: String) {
    LISTENING("listening"), RESTING("resting"), THINKING("thinking"), TALKING("talking"),
    POINTING("pointing"), HAPPY("happy"), SLEEPY("sleepy");

    companion object {
        fun from(raw: String?): Mood = entries.firstOrNull { it.raw == raw } ?: LISTENING
    }
}

/** What the phone should show right now. gazeX: -1 left … 1 right, gazeY: -1 up … 1 down. */
data class FaceState(
    val gazeX: Double = 0.0,
    val gazeY: Double = 0.0,
    val mood: Mood = Mood.LISTENING,
    val talk: Double = 0.0,
)

/** One line of newline-delimited JSON. Null fields are left out, exactly like Swift's Codable. */
data class Packet(
    val face: FaceState? = null,
    val hello: String? = null,
    val volume: Double? = null,
    val command: String? = null,
    val audio: String? = null,
    val speech: Int? = null,
    val callID: String? = null,
    val tool: String? = null,
    val text: String? = null,
    val image: String? = null,
) {
    fun toJson(): String {
        val o = JSONObject()
        face?.let {
            o.put("face", JSONObject().put("gazeX", it.gazeX).put("gazeY", it.gazeY)
                .put("mood", it.mood.raw).put("talk", it.talk))
        }
        hello?.let { o.put("hello", it) }
        volume?.let { o.put("volume", it) }
        command?.let { o.put("command", it) }
        audio?.let { o.put("audio", it) }
        speech?.let { o.put("speech", it) }
        callID?.let { o.put("callID", it) }
        tool?.let { o.put("tool", it) }
        text?.let { o.put("text", it) }
        image?.let { o.put("image", it) }
        return o.toString()
    }

    companion object {
        fun fromJson(line: String): Packet? = try {
            val o = JSONObject(line)
            val f = o.optJSONObject("face")
            Packet(
                face = f?.let {
                    FaceState(it.optDouble("gazeX", 0.0), it.optDouble("gazeY", 0.0),
                        Mood.from(it.optString("mood")), it.optDouble("talk", 0.0))
                },
                hello = o.optStringOrNull("hello"),
                volume = if (o.has("volume")) o.optDouble("volume") else null,
                command = o.optStringOrNull("command"),
                audio = o.optStringOrNull("audio"),
                speech = if (o.has("speech")) o.optInt("speech") else null,
                callID = o.optStringOrNull("callID"),
                tool = o.optStringOrNull("tool"),
                text = o.optStringOrNull("text"),
                image = o.optStringOrNull("image"),
            )
        } catch (e: Exception) {
            null
        }
    }
}

private fun JSONObject.optStringOrNull(key: String): String? =
    if (has(key) && !isNull(key)) getString(key) else null

/** Newline-delimited JSON over one TCP socket. All callbacks run on the main thread. */
class LineConnection(private val host: String, private val port: Int) {
    var onPacket: ((Packet) -> Unit)? = null
    var onConnected: (() -> Unit)? = null
    var onClosed: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val writer = Executors.newSingleThreadExecutor()
    @Volatile private var socket: Socket? = null
    @Volatile private var closed = false

    fun start() {
        Thread {
            try {
                val s = Socket()
                s.tcpNoDelay = true
                s.keepAlive = true
                s.connect(InetSocketAddress(host, port), 5000)
                socket = s
                if (closed) { s.close(); return@Thread }
                main.post { onConnected?.invoke() }
                val input = BufferedInputStream(s.getInputStream(), 64 * 1024)
                val buffer = java.io.ByteArrayOutputStream()
                while (!closed) {
                    val b = input.read()
                    if (b < 0) break
                    if (b == 0x0A) {
                        val line = buffer.toString(Charsets.UTF_8.name())
                        buffer.reset()
                        Packet.fromJson(line)?.let { p -> main.post { if (!closed) onPacket?.invoke(p) } }
                    } else {
                        buffer.write(b)
                    }
                }
            } catch (_: Exception) {
            } finally {
                cancel()
            }
        }.apply { isDaemon = true; start() }
    }

    fun send(packet: Packet) {
        val line = (packet.toJson() + "\n").toByteArray(Charsets.UTF_8)
        try {
            writer.execute {
                try {
                    socket?.getOutputStream()?.apply { write(line); flush() }
                } catch (_: Exception) {
                    cancel()
                }
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
        }
    }

    fun cancel() {
        if (closed) return
        closed = true
        try { socket?.close() } catch (_: Exception) {}
        writer.shutdown()
        main.post { onClosed?.invoke() }
    }
}
