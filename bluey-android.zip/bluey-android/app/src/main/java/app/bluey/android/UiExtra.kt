package app.bluey.android

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/** Teach him the wake phrase ("Hey Bluey"): three or four recordings, then he listens for it all the time, silently. */
@Composable
fun WakeTab(settings: Settings, templates: WakeTemplates, ownWake: OwnWake, awake: Boolean) {
    val skin = Palette.skin
    val version = templates.version
    val count = remember(version, skin.id) { templates.count(skin.id) }
    var recording by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("WECKWORT FÜR ${skin.name.uppercase()}", color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 12.sp)
                Text("Nimm den Satz „Hey ${skin.name}“ drei- bis viermal mit deiner Stimme auf. Danach hört das Handy im Schlaf " +
                    "durchgehend und lautlos darauf (ohne Piepton), und es verlässt nichts das Handy. Jede Farbe hat ihr eigenes Weckwort.",
                    color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 13.sp)
            }
        }
        item {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (count >= 3) "$count Aufnahmen, das Weckwort ist bereit." else "$count von mindestens 3 Aufnahmen",
                    color = Palette.text, fontFamily = PlexSans, fontSize = 15.sp)
                LinearProgressIndicator(progress = { min(1f, count / 3f) }, color = Palette.berry2, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chip(if (recording) "Ich höre zu …" else "Aufnehmen") {
                        when {
                            awake -> info = "Schick ihn erst schlafen (doppelt tippen)."
                            recording -> {}
                            else -> {
                                recording = true
                                info = "Sag jetzt „Hey ${skin.name}“."
                                ownWake.captureOne { seq ->
                                    recording = false
                                    if (seq != null) { templates.add(skin.id, seq); info = "Aufgenommen." } else info = "Ich habe nichts gehört. Nochmal?"
                                }
                            }
                        }
                    }
                    Chip("Zurücksetzen") { templates.clear(skin.id); info = "" }
                }
                if (info.isNotEmpty()) Text(info, color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 13.sp)
            }
        }
        item {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("EMPFINDLICHKEIT", color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 12.sp)
                Slider(
                    value = settings.wakeSensitivity, onValueChange = { settings.wakeSensitivity = it }, valueRange = 0.7f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = Palette.berry2, activeTrackColor = Palette.berry2),
                )
                Text("Wacht er zu schnell auf: nach links. Wacht er nie auf: nach rechts.", color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 13.sp)
            }
        }
        item {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(if (ownWake.testMode) "Test beenden" else "Weckwort testen") {
                    if (awake) info = "Schick ihn erst schlafen (doppelt tippen)." else ownWake.testMode = !ownWake.testMode
                }
                if (ownWake.testMode) {
                    Text("Sag „Hey ${skin.name}“. Letzter Wert: %.2f, Grenze: %.2f".format(ownWake.lastScore, ownWake.lastLimit),
                        color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 12.sp)
                    if (ownWake.heard) Text("Erkannt!", color = Palette.berry1, fontFamily = Fredoka, fontSize = 22.sp)
                }
            }
        }
    }
}

/** Duo mode: pair with a second phone that has Bluey on it, and let the two talk. */
@Composable
fun DuoTab(duo: DuoLink, live: LiveVoice) {
    val context = LocalContext.current
    var topic by remember { mutableStateOf("") }
    var showList by remember { mutableStateOf(false) }
    LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("DUO: ZWEI BLUEYS", color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 12.sp)
                Text("Stell zwei Handys mit Bluey nebeneinander. Koppelt sie vorher einmal in den Bluetooth-Einstellungen. " +
                    "Auf dem einen Handy tippst du „Dieses Handy wartet“, auf dem anderen „Mit Handy verbinden“. " +
                    "Dann unterhalten sich die beiden, jeder mit seiner Stimme.",
                    color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 13.sp)
                Chip("Bluetooth-Einstellungen öffnen") {
                    try { context.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (_: Exception) {}
                }
            }
        }
        when (duo.state) {
            DuoState.OFF -> {
                item {
                    androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Chip("Dieses Handy wartet") { duo.listen() }
                            Chip("Mit Handy verbinden") { showList = !showList }
                        }
                        if (duo.message.isNotEmpty()) Text(duo.message, color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 13.sp)
                    }
                }
                if (showList) {
                    val devices = duo.paired()
                    if (devices.isEmpty()) {
                        item {
                            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Keine gekoppelten Geräte gefunden. Koppel zuerst die Handys (oben), oder erlaube mir Bluetooth.",
                                    color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 13.sp)
                                Chip("Bluetooth erlauben") { duo.requestPermission { } }
                            }
                        }
                    }
                    items(devices, key = { it.address }) { d ->
                        val label = try { d.name } catch (_: SecurityException) { null } ?: d.address
                        Text(label, color = Palette.text, fontFamily = PlexSans, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Palette.panel)
                                .clickable { showList = false; duo.connect(d) }.padding(14.dp))
                    }
                }
            }
            DuoState.WAITING, DuoState.CONNECTING -> item {
                androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(duo.message, color = Palette.text, fontFamily = PlexSans, fontSize = 15.sp)
                    Chip("Abbrechen") { duo.close() }
                }
            }
            DuoState.CONNECTED -> {
                item {
                    androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Verbunden mit ${duo.peerName ?: "…"}", color = Palette.text, fontFamily = Fredoka, fontSize = 22.sp)
                        Text("Das andere Handy steht:", color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Chip("links", duo.side == "left") { duo.side = "left" }
                            Chip("rechts", duo.side == "right") { duo.side = "right" }
                        }
                    }
                }
                item {
                    androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = topic, onValueChange = { topic = it }, singleLine = true, label = { Text("Thema (z. B. Pizza)") },
                            colors = darkFieldColors(), modifier = Modifier.fillMaxWidth(),
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Chip("Gespräch starten") { live.startDuo(topic) }
                            Chip("Gespräch beenden") { live.endDuo(true) }
                            Chip("Trennen") { live.endDuo(true); duo.close() }
                        }
                        if (live.duoActive) Text("Die beiden unterhalten sich gerade.", color = Palette.berry1, fontFamily = PlexSans, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

/** While two Blueys talk: dots and notes flow from the one who speaks to the one who listens, and the other's words pop up at its side. */
@Composable
fun DuoOverlay(live: LiveVoice, duo: DuoLink) {
    if (duo.state != DuoState.CONNECTED) return
    val t = rememberFrameTime()
    val peer = duo.peerSkin ?: Skins.pinky
    val me = Palette.skin
    val left = duo.side == "left"
    val talking = live.duoActive
    val iSpeak = talking && live.state == LiveVoice.State.SPEAKING
    val peerSpeaks = talking && live.duoPeerLine.isNotEmpty() && !iSpeak

    Box(Modifier.fillMaxSize()) {
        if (iSpeak || peerSpeaks) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val edge = if (left) 0f else w
                val from = if (iSpeak) w / 2f else edge
                val to = if (iSpeak) edge else w / 2f
                val color = if (iSpeak) me.c2 else peer.c2
                val paint = android.graphics.Paint().apply {
                    isAntiAlias = true; textSize = 34.dp.toPx() / 2f; isFakeBoldText = true
                }
                val n = 8
                for (i in 0 until n) {
                    val phase = ((t * 0.55 + i / n.toDouble()) % 1.0).toFloat()
                    val lift = sin(phase * PI.toFloat())
                    val x = from + (to - from) * phase
                    val y = h * 0.30f + sin(phase * 7f + i) * h * 0.05f - lift * h * 0.10f
                    if (i % 3 == 0) {
                        paint.color = android.graphics.Color.argb((255 * (0.35f + 0.6f * lift)).toInt().coerceIn(0, 255),
                            (color.red * 255).toInt(), (color.green * 255).toInt(), (color.blue * 255).toInt())
                        drawContext.canvas.nativeCanvas.drawText(if (i % 2 == 0) "♪" else "♥", x, y, paint)
                    } else {
                        drawCircle(color.copy(alpha = 0.3f + 0.55f * lift), (4f + 7f * lift).dp.toPx(), Offset(x, y))
                    }
                }
            }
        }
        if (peerSpeaks) {
            Text(
                live.duoPeerLine, color = Color.White, fontFamily = PlexSans, fontWeight = FontWeight.Medium, fontSize = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(if (left) Alignment.CenterStart else Alignment.CenterEnd).padding(14.dp).widthIn(max = 230.dp)
                    .clip(RoundedCornerShape(18.dp)).background(peer.c3.copy(alpha = 0.92f)).padding(horizontal = 14.dp, vertical = 10.dp),
            )
        }
        Text(
            if (talking) "Duo mit ${peer.name} · tippen zum Beenden" else "Verbunden mit ${peer.name}",
            color = Color.White, fontFamily = PlexSans, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp).clip(RoundedCornerShape(50))
                .background(peer.c3.copy(alpha = 0.85f)).clickable(enabled = talking) { live.endDuo(true) }
                .padding(horizontal = 14.dp, vertical = 7.dp),
        )
    }
}
