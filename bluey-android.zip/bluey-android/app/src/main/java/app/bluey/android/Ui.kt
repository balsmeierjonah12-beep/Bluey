package app.bluey.android

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date
import kotlin.math.PI
import kotlin.math.sin

val Fredoka = FontFamily(Font(R.font.fredoka, FontWeight.Bold))
val PlexSans = FontFamily(Font(R.font.ibm_plex_sans))
val PlexMono = FontFamily(Font(R.font.ibm_plex_mono))

private val BerryBlue = Color(0xFF4F8BFF)

@Composable
fun rememberFrameTime(): Double {
    var now by remember { mutableDoubleStateOf(0.0) }
    LaunchedEffect(Unit) { while (true) androidx.compose.runtime.withFrameNanos { now = it / 1e9 } }
    return now
}

/** Shows which mode he's in: a solid border around the screen (blue while he listens) plus a small label. */
@Composable
fun ModeIndicator(state: LiveVoice.State) {
    data class Look(val color: Color, val label: String?, val icon: androidx.compose.ui.graphics.vector.ImageVector, val border: Float, val pulse: Double)
    val look = when (state) {
        LiveVoice.State.ASLEEP -> Look(Palette.inkSoft, null, Icons.Filled.Visibility, 0f, 0.0)
        LiveVoice.State.WAKING -> Look(Color(0xFFFFD66B), "Waking up", Icons.Filled.WbSunny, 6f, 1.6)
        LiveVoice.State.LISTENING -> Look(BerryBlue, "Listening · hold to ask", Icons.Filled.Hearing, 10f, 0.0)
        LiveVoice.State.ASKING -> Look(BerryBlue, "I'm all ears", Icons.Filled.Mic, 16f, 1.2)
        LiveVoice.State.THINKING -> Look(Color(0xFFC79BFF), "Thinking", Icons.Filled.AutoAwesome, 8f, 1.1)
        LiveVoice.State.SPEAKING -> Look(Color(0xFFFF9AD0), "Replying", Icons.Filled.ChatBubble, 8f, 0.0)
    }
    val t = if (look.pulse > 0) rememberFrameTime() else 0.0
    val wave = if (look.pulse > 0) 0.5 + 0.5 * sin(t * look.pulse * 2 * PI) else 1.0
    Box(Modifier.fillMaxSize()) {
        if (look.border > 0) {
            Canvas(Modifier.fillMaxSize()) {
                val w = look.border * density
                val radius = 28.dp.toPx()
                drawRoundRect(
                    look.color.copy(alpha = if (look.pulse > 0) (0.65 + 0.35 * wave).toFloat() else 1f),
                    topLeft = Offset(w / 2, w / 2), size = Size(size.width - w, size.height - w),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius),
                    style = Stroke(w),
                )
            }
        }
        val labelled = look.label != null
        Row(
            Modifier
                .padding(top = (14 + look.border).dp, start = (24 + look.border).dp)
                .heightIn(min = 34.dp).widthIn(min = 34.dp)
                .clip(RoundedCornerShape(50))
                .background(if (labelled) look.color else Color.White.copy(alpha = 0.06f))
                .padding(horizontal = if (labelled) 14.dp else 0.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(look.icon, null, Modifier.size(16.dp).padding(start = if (labelled) 0.dp else 0.dp),
                tint = if (labelled) Color.White else look.color.copy(alpha = 0.7f))
            if (labelled) {
                Spacer(Modifier.width(7.dp))
                Text(look.label!!, color = Color.White, fontFamily = Fredoka, fontSize = 16.sp)
            }
        }
    }
}

/** A tiny, quiet speaker button in the top-right corner: chirp volume, a test hi, and which Mac to pair with. */
@Composable
fun SoundButton(link: MacLink, live: LiveVoice) {
    var volume by remember { mutableStateOf(live.volume) }
    var open by remember { mutableStateOf(false) }
    var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(lastTouch, open) {
        if (open) { delay(6000); open = false }
    }
    Column(
        Modifier.fillMaxSize().padding(top = 10.dp, end = 14.dp),
        horizontalAlignment = Alignment.End,
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).clickable { open = !open; lastTouch = System.currentTimeMillis() },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = if (open) 0.14f else 0.06f)), contentAlignment = Alignment.Center) {
                val icon = when { open -> Icons.Filled.Close; volume < 0.01f -> Icons.Filled.VolumeOff; volume < 0.5f -> Icons.Filled.VolumeDown; else -> Icons.Filled.VolumeUp }
                Icon(icon, "Sound settings", Modifier.size(16.dp), tint = Color.White.copy(alpha = if (open) 0.9f else 0.35f))
            }
        }
        AnimatedVisibility(open) {
            Column(
                Modifier.padding(top = 10.dp).width(260.dp).clip(RoundedCornerShape(18.dp))
                    .background(Palette.panel.copy(alpha = 0.95f)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("CHIRP VOLUME", color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 12.sp)
                    Text("${(volume * 100).toInt()}%", color = Color.White, fontFamily = PlexMono, fontSize = 13.sp)
                }
                Slider(
                    value = volume, onValueChange = { volume = it; live.volume = it; lastTouch = System.currentTimeMillis() },
                    colors = SliderDefaults.colors(thumbColor = Palette.berry2, activeTrackColor = Palette.berry2),
                )
                Box(
                    Modifier.fillMaxWidth().heightIn(min = 44.dp).clip(RoundedCornerShape(12.dp))
                        .background(Brush.linearGradient(Palette.gradient))
                        .alpha(if (link.connected) 1f else 0.4f)
                        .clickable(enabled = link.connected) { live.sayHi(); lastTouch = System.currentTimeMillis() },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(if (live.state == LiveVoice.State.ASLEEP) "Wake him up" else "Say hi",
                        color = Color.White, fontFamily = PlexSans, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
                if (link.macs.size > 1) {
                    Text("MAC", color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 12.sp)
                    link.macs.forEach { name ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 36.dp).clickable { link.choose(name); lastTouch = System.currentTimeMillis() },
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(name, color = Color.White, fontFamily = PlexSans, fontSize = 14.sp, maxLines = 1, modifier = Modifier.weight(1f))
                            if (name == link.currentMac) {
                                Icon(if (link.connected) Icons.Filled.Check else Icons.Filled.MoreHoriz, null, tint = Palette.berry2, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
                if (!link.connected) {
                    Text("Connect to your Mac to talk to him.", color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 12.sp)
                }
            }
        }
    }
}

/** Shown until the phone finds the Mac: a sleepy blob and how to wake him up. */
@Composable
fun PairingView(onPlay: () -> Unit) {
    Row(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 72.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(56.dp, Alignment.CenterHorizontally),
    ) {
        val t = rememberFrameTime()
        Canvas(Modifier.size(width = 220.dp, height = 190.dp)) {
            val s = 1f + 0.02f * sin(t * 1.1).toFloat()
            val rect = Rect(0f, 0f, size.width, size.height)
            withTransform({ scale(s, s, Offset(size.width / 2, size.height)) }) {
                drawPath(blobPath(rect), skinBrush(rect), alpha = 0.9f)
                val eyeY = size.height * 0.38f
                drawLine(Palette.ink, Offset(size.width * 0.5f - 62.dp.toPx(), eyeY), Offset(size.width * 0.5f - 16.dp.toPx(), eyeY), 7.dp.toPx(), StrokeCap.Round)
                drawLine(Palette.ink, Offset(size.width * 0.5f + 16.dp.toPx(), eyeY), Offset(size.width * 0.5f + 62.dp.toPx(), eyeY), 7.dp.toPx(), StrokeCap.Round)
                drawOval(Palette.nose, Offset(size.width * 0.5f - 5.dp.toPx(), size.height * 0.62f), Size(18.dp.toPx(), 12.dp.toPx()))
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Wake me up from your Mac", color = Palette.text, fontFamily = Fredoka, fontSize = 32.sp)
            Text(
                "Open Bluey in your Mac's menu bar. Keep both on the same Wi-Fi and I'll find it.",
                color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 16.sp, modifier = Modifier.widthIn(max = 380.dp),
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator(Modifier.size(18.dp), color = Palette.berry1, strokeWidth = 2.dp)
                Text("Looking for your Mac", color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 13.sp)
            }
            Box(
                Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(14.dp)).background(Palette.panel)
                    .clickable { onPlay() }.padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Play without the Mac", color = Palette.text, fontFamily = PlexSans, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
        }
    }
}

/** Bluey's app: the list of sessions, and one session's transcript. */
@Composable
fun BlueyAppView(store: SessionStore, onClose: () -> Unit) {
    var openID by remember { mutableStateOf<String?>(null) }
    val session = store.sessions.firstOrNull { it.id == openID }
    Column(Modifier.fillMaxSize().background(Color(0xFF0E0C14)).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 24.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (session == null) "Bluey" else "Session", color = Palette.text, fontFamily = Fredoka, fontSize = 26.sp, modifier = Modifier.weight(1f))
            Box(Modifier.size(44.dp).clip(CircleShape).clickable { if (session != null) openID = null else onClose() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Close", tint = Color.White.copy(alpha = 0.7f))
            }
        }
        if (session == null) {
            if (store.sessions.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No sessions yet. Double tap him to start one.", color = Palette.inkSoft, fontFamily = PlexSans, fontSize = 16.sp)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(store.sessions, key = { it.id }) { s ->
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Palette.panel)
                                .clickable { openID = s.id }.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            val whenText = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(s.startedMs))
                            val minutes = (s.durationMs / 60_000).toInt()
                            Text("$whenText · ${if (minutes < 1) "<1" else minutes.toString()} min · ${s.questionCount} questions" +
                                (if (s.transcribing > 0) " · transcribing…" else ""),
                                color = Palette.inkSoft, fontFamily = PlexMono, fontSize = 12.sp)
                            Text(s.summary, color = Palette.text, fontFamily = PlexSans, fontSize = 16.sp, maxLines = 2)
                        }
                    }
                }
            }
        } else {
            SessionDetail(store, session) { openID = null }
        }
    }
}

@Composable
private fun SessionDetail(store: SessionStore, s: BlueySession, onDeleted: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(2000); copied = false } }
    val timeFmt = remember { DateFormat.getTimeInstance(DateFormat.MEDIUM) }

    fun prompt(): String {
        val root = "~/Documents/Bluey Notes"
        val path = s.notesPath?.let { p ->
            val i = p.indexOf("/Documents/Bluey Notes"); if (i >= 0) "~" + p.substring(i) else p
        } ?: "$root/ (the folder starting ${java.text.SimpleDateFormat("yyyy-MM-dd").format(Date(s.startedMs))})"
        return "I recorded a meeting with my Bluey app on ${DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT).format(Date(s.startedMs))}. " +
            "The notes are on my Mac in $path\n\n" +
            "- notes.md: the full transcript with timestamps and speaker labels (A, B, … per five-minute chunk), plus my questions to Bluey, its replies and research reports. Start here.\n" +
            "- session.json: the same data, structured.\n" +
            "- audio/: the original recording in five-minute chunks.\n\n" +
            "All my sessions are in $root/, one folder per session (see README.md there). Read the notes, then help me with: "
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            @Composable fun Chip(label: String, onClick: () -> Unit) = Box(
                Modifier.heightIn(min = 40.dp).clip(RoundedCornerShape(12.dp)).background(Palette.panel).clickable(onClick = onClick).padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label, color = Palette.text, fontFamily = PlexSans, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
            Chip(if (copied) "Copied" else "Copy prompt for agent") { clipboard.setText(AnnotatedString(prompt())); copied = true }
            Chip("Share") {
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, s.exportText) }
                context.startActivity(Intent.createChooser(send, "Share session"))
            }
            Chip("Delete") { store.delete(s.id); onDeleted() }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(s.displayEntries, key = { it.id }) { e ->
                val who = when (e.kind) {
                    EntryKind.TRANSCRIPT -> "Speaker ${e.speaker ?: "?"}"
                    EntryKind.HEARD -> "You"
                    EntryKind.ASKED -> "You asked"
                    EntryKind.REPLY -> "Bluey"
                    EntryKind.REPORT -> "Research"
                }
                val accent = when (e.kind) { EntryKind.ASKED -> BerryBlue; EntryKind.REPLY -> Color(0xFFFF9AD0); EntryKind.REPORT -> Color(0xFFC79BFF); else -> Palette.inkSoft }
                Column(Modifier.fillMaxWidth()) {
                    Text("${timeFmt.format(Date(e.timeMs))} · $who", color = accent, fontFamily = PlexMono, fontSize = 11.sp)
                    Text(e.text, color = Palette.text, fontFamily = PlexSans, fontSize = 15.sp)
                }
            }
        }
    }
}
