package app.bluey.android

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.AlarmClock
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Things he can do on the phone itself. [run] answers on the spot, or returns null for tools it doesn't know. */
class DeviceTools(private val context: Context, private val settings: Settings, private val voice: VoiceID) {
    private var torchOn = false

    fun run(name: String, args: JSONObject): String? = when (name) {
        "get_time" -> SimpleDateFormat("EEEE, d. MMMM yyyy, HH:mm 'Uhr'", Locale.GERMANY).format(Date())
        "set_timer" -> timer(args.optInt("seconds", 0), args.optString("label", ""))
        "set_alarm" -> alarm(args.optInt("hour", -1), args.optInt("minute", 0), args.optString("label", ""))
        "flashlight" -> torch(args.optBoolean("on", true))
        "remember" -> {
            val note = args.optString("note", "").trim()
            if (note.isEmpty()) "Nichts zum Merken angegeben." else { settings.addNote(note); "Gemerkt." }
        }
        "forget" -> {
            val removed = settings.removeNotes(args.optString("contains", ""))
            if (removed > 0) "Vergessen ($removed Notiz(en))." else "Dazu hatte ich nichts notiert."
        }
        "learn_my_voice" -> {
            val who = args.optString("name", "").trim()
            if (who.isEmpty()) "Ich brauche den Namen der Person."
            else {
                voice.startEnroll(who, ownRecording = false)
                "Ich lerne jetzt die Stimme von $who. Sag der Person, sie soll etwa 20 Sekunden einfach drauflos erzählen. Ich melde mich, wenn ich fertig bin."
            }
        }
        else -> null
    }

    private fun start(intent: Intent): Boolean = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: Exception) { false }

    private fun timer(seconds: Int, label: String): String {
        if (seconds <= 0) return "Ich brauche eine Dauer in Sekunden."
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (start(intent)) "Timer läuft: $seconds Sekunden." else "Auf diesem Handy konnte ich keinen Timer stellen."
    }

    private fun alarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23 || minute !in 0..59) return "Ich brauche eine gültige Uhrzeit."
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (start(intent)) "Wecker gestellt auf %02d:%02d.".format(hour, minute) else "Auf diesem Handy konnte ich keinen Wecker stellen."
    }

    private fun torch(on: Boolean): String = try {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = manager.cameraIdList.firstOrNull {
            val c = manager.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        if (id == null) "Dieses Handy hat keine Taschenlampe."
        else { manager.setTorchMode(id, on); torchOn = on; if (on) "Taschenlampe an." else "Taschenlampe aus." }
    } catch (_: Exception) { "Die Taschenlampe geht gerade nicht." }
}
