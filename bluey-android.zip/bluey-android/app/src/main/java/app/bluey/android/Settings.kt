package app.bluey.android

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** The Gemini key (stored encrypted on this phone), the chosen color and a few switches. */
class Settings(context: Context) {
    private val prefs: SharedPreferences = try {
        val master = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "bluey_secure", master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        context.getSharedPreferences("bluey_secure_fallback", Context.MODE_PRIVATE)
    }

    private var keyState by mutableStateOf(prefs.getString("geminiKey", "") ?: "")
    private var seeMeState by mutableStateOf(prefs.getBoolean("seeMe", true))
    private var wakeWordState by mutableStateOf(prefs.getBoolean("wakeWord", true))

    init { Palette.skin = Skins.byId(prefs.getString("color", "blue")) }

    var apiKey: String
        get() = keyState
        set(value) { keyState = value.trim(); prefs.edit().putString("geminiKey", keyState).apply() }

    /** Which berry he is. Changes his look, his name, the wake words and his voice. */
    var skin: Skin
        get() = Palette.skin
        set(value) { Palette.skin = value; prefs.edit().putString("color", value.id).apply() }

    /** Let him see you through the front camera while he's awake (a small picture every few seconds). */
    var seeMe: Boolean
        get() = seeMeState
        set(value) { seeMeState = value; prefs.edit().putBoolean("seeMe", value).apply() }

    /** Wake him by saying "Hey <name>". */
    var wakeWord: Boolean
        get() = wakeWordState
        set(value) { wakeWordState = value; prefs.edit().putBoolean("wakeWord", value).apply() }

    val hasKey get() = keyState.isNotBlank()
}
