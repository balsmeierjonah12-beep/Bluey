package app.bluey.android

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** The OpenAI key (stored encrypted on this phone) and a few switches. */
class Settings(context: Context) {
    private val prefs: SharedPreferences = try {
        val master = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "bluey_secure", master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        context.getSharedPreferences("bluey_secure_fallback", Context.MODE_PRIVATE)
    }

    private var keyState by mutableStateOf(prefs.getString("openaiKey", "") ?: "")
    private var seeMeState by mutableStateOf(prefs.getBoolean("seeMe", true))

    var apiKey: String
        get() = keyState
        set(value) { keyState = value.trim(); prefs.edit().putString("openaiKey", keyState).apply() }

    /** Send a fresh camera photo along with every question, so he can see you. */
    var seeMe: Boolean
        get() = seeMeState
        set(value) { seeMeState = value; prefs.edit().putBoolean("seeMe", value).apply() }

    val hasKey get() = keyState.isNotBlank()
}
