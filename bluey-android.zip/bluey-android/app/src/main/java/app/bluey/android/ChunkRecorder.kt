package app.bluey.android

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import java.io.File

/**
 * Records everything the mic hears during a session to small AAC (.m4a) files, five minutes each,
 * so an all-day session never builds one giant file and each piece can be transcribed as soon as it's done.
 * Input is 16-bit mono PCM at 24 kHz.
 */
class ChunkRecorder(private val root: File) {
    data class Chunk(val sessionID: String, val index: Int, val file: File, val startedMs: Long)

    companion object {
        const val CHUNK_SECONDS = 300
        const val RATE = 24_000
        fun chunkFile(root: File, session: String, index: Int) =
            File(File(root, session), "chunk-%03d.m4a".format(index))
    }

    /** Called on the main thread each time a chunk is finished. */
    var onChunk: ((Chunk) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("bluey-recorder").apply { start() }
    private val worker = Handler(thread.looper)

    private var sessionID: String? = null
    private var chunkIndex = 0
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var track = -1
    private var muxerStarted = false
    private var file: File? = null
    private var chunkStartedMs = 0L
    private var samplesInChunk = 0L
    private val info = MediaCodec.BufferInfo()

    fun start(session: String) = worker.post {
        closeChunk()
        sessionID = session
        chunkIndex = 0
    }

    /** Feeds PCM from the mic thread (the array is copied). */
    fun append(pcm: ShortArray, length: Int) {
        val copy = pcm.copyOf(length)
        worker.post { write(copy) }
    }

    fun finish() = worker.post {
        closeChunk()
        sessionID = null
    }

    private fun write(pcm: ShortArray) {
        val session = sessionID ?: return
        if (codec != null && samplesInChunk >= CHUNK_SECONDS.toLong() * RATE) closeChunk()
        if (codec == null && !openChunk(session)) return
        val c = codec ?: return
        var offset = 0
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            bytes[2 * i] = (pcm[i].toInt() and 0xFF).toByte()
            bytes[2 * i + 1] = ((pcm[i].toInt() shr 8) and 0xFF).toByte()
        }
        while (offset < bytes.size) {
            val index = c.dequeueInputBuffer(10_000)
            if (index < 0) { drain(false); continue }
            val buf = c.getInputBuffer(index) ?: return
            buf.clear()
            val n = minOf(buf.remaining(), bytes.size - offset)
            buf.put(bytes, offset, n)
            val ptsUs = samplesInChunk * 1_000_000L / RATE
            c.queueInputBuffer(index, 0, n, ptsUs, 0)
            samplesInChunk += n / 2
            offset += n
            drain(false)
        }
    }

    private fun openChunk(session: String): Boolean = try {
        chunkIndex += 1
        val f = chunkFile(root, session, chunkIndex)
        f.parentFile?.mkdirs()
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 48_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024)
        }
        val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        c.start()
        codec = c
        muxer = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        track = -1
        muxerStarted = false
        file = f
        chunkStartedMs = System.currentTimeMillis()
        samplesInChunk = 0
        true
    } catch (e: Exception) {
        codec = null; muxer = null
        false
    }

    private fun drain(endOfStream: Boolean) {
        val c = codec ?: return
        var idle = 0
        while (true) {
            val out = c.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
            when {
                out == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream || ++idle > 50) return
                out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    track = muxer?.addTrack(c.outputFormat) ?: -1
                    muxer?.start()
                    muxerStarted = true
                }
                out >= 0 -> {
                    val buf = c.getOutputBuffer(out)
                    if (buf != null && info.size > 0 && muxerStarted &&
                        (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer?.writeSampleData(track, buf, info)
                    }
                    c.releaseOutputBuffer(out, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }
    }

    private fun closeChunk() {
        val c = codec ?: return
        val session = sessionID
        try {
            val index = c.dequeueInputBuffer(50_000)
            if (index >= 0) {
                c.queueInputBuffer(index, 0, 0, samplesInChunk * 1_000_000L / RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            drain(true)
        } catch (_: Exception) {
        }
        try { c.stop() } catch (_: Exception) {}
        try { c.release() } catch (_: Exception) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        val f = file
        val hadAudio = muxerStarted
        codec = null; muxer = null; file = null; muxerStarted = false
        if (!hadAudio) { f?.delete(); chunkIndex -= 1; return }
        if (session != null && f != null) {
            val chunk = Chunk(session, chunkIndex, f, chunkStartedMs)
            main.post { onChunk?.invoke(chunk) }
        }
    }
}
