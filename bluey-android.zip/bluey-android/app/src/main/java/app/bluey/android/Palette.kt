package app.bluey.android

import androidx.compose.ui.graphics.Color

/** Blueberry colors from the design canvas (same values as Shared/Palette.swift). */
object Palette {
    val berry1 = Color(0xFFA9BCFF)
    val berry2 = Color(0xFF6C86F5)
    val berry3 = Color(0xFF4254D6)
    val berry4 = Color(0xFF2B2F8F)
    val nose = Color(0xFF1C1F66)
    val ink = Color(0xFF17151F)
    val inkSoft = Color(0xFFB9B2CC)
    val panel = Color(0xFF1E1B29)
    val text = Color(0xFFF4F1FA)

    val gradient = listOf(berry1, berry2, berry3, berry4)
    val gradientStops = listOf(0f, 0.34f, 0.68f, 1f)
}
