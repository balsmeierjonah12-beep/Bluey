package app.bluey.android

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import kotlin.random.Random

enum class DuoState { OFF, WAITING, CONNECTING, CONNECTED }

/**
 * Duo mode: two phones, each with a Bluey, side by side. Google's Nearby Connections finds the other phone over
 * Bluetooth by itself (no pairing). Both phones tap "Duo starten", then they send each other what they say as text.
 */
class DuoLink(private val context: Context) {
    companion object {
        private const val SERVICE_ID = "app.bluey.android.duo"
        private const val SEARCH_MS = 90_000L
    }

    private val prefs = context.getSharedPreferences("bluey", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())

    var state by mutableStateOf(DuoState.OFF); private set
    var peerName by mutableStateOf<String?>(null); private set
    var peerSkin by mutableStateOf<Skin?>(null); private set
    var message by mutableStateOf(""); private set

    private var sideState by mutableStateOf(prefs.getString("duoSide", "right") ?: "right")
    /** Where the other phone stands: "left" or "right" of this one. */
    var side: String
        get() = sideState
        set(value) { sideState = value; prefs.edit().putString("duoSide", value).apply() }

    var onSay: ((String) -> Unit)? = null
    var onStart: ((String) -> Unit)? = null
    var onStop: (() -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    /** Asks for the permissions below; calls back with whether all were granted. */
    var requestPermission: ((Boolean) -> Unit) -> Unit = { done -> done(true) }

    private val client: ConnectionsClient by lazy { Nearby.getConnectionsClient(context) }
    private var myId = 0
    private var peer: String? = null
    private val asked = HashSet<String>()
    private val timeout = Runnable {
        if (state == DuoState.WAITING || state == DuoState.CONNECTING) {
            reset()
            message = "Ich habe das andere Handy nicht gefunden. Läuft dort auch „Duo starten“? Sind Bluetooth und Standort an?"
        }
    }

    fun missingPermissions(): List<String> {
        val needed = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            needed.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            needed.add(Manifest.permission.BLUETOOTH_CONNECT)
            needed.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        if (Build.VERSION.SDK_INT <= 32) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        return needed.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
    }

    /** Both phones do this: be visible and look for the other one. The phone with the smaller number asks for the connection. */
    fun start() {
        if (missingPermissions().isNotEmpty()) {
            requestPermission { ok ->
                if (ok) begin() else message = "Ich brauche die Erlaubnis für Geräte in der Nähe (Bluetooth). Erlaube sie in den Handy-Einstellungen für Bluey."
            }
            return
        }
        begin()
    }

    private fun ownName() = "${Palette.skin.id}|${Palette.skin.name}|$myId"

    private fun begin() {
        reset()
        myId = Random.nextInt(100_000, 999_999)
        state = DuoState.WAITING
        message = "Ich suche das andere Handy … Tippe dort auch auf „Duo starten“."
        try {
            client.startAdvertising(
                ownName(), SERVICE_ID, lifecycle,
                AdvertisingOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build(),
            ).addOnFailureListener { e -> failed("Sichtbar werden", e) }
            client.startDiscovery(
                SERVICE_ID, discovery,
                DiscoveryOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build(),
            ).addOnFailureListener { e -> failed("Suchen", e) }
        } catch (e: Exception) {
            failed("Starten", e)
            return
        }
        main.removeCallbacks(timeout)
        main.postDelayed(timeout, SEARCH_MS)
    }

    private fun failed(what: String, e: Exception) {
        val code = (e as? ApiException)?.statusCode?.toString() ?: (e.message ?: "?")
        reset()
        message = "$what hat nicht geklappt ($code). Sind Bluetooth und Standort an, und gibt es die Google Play-Dienste?"
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val parts = info.endpointName.split("|")
            val theirId = parts.getOrNull(2)?.toIntOrNull() ?: return
            val theirName = parts.getOrNull(1) ?: "dem anderen Handy"
            if (peer != null || endpointId in asked) return
            if (myId < theirId) {
                asked.add(endpointId)
                message = "Gefunden: $theirName. Verbinde …"
                client.requestConnection(ownName(), endpointId, lifecycle).addOnFailureListener { e ->
                    asked.remove(endpointId)
                    message = "Das Verbinden hat nicht geklappt (${(e as? ApiException)?.statusCode ?: e.message}). Ich versuche es weiter."
                }
            } else {
                message = "Gefunden: $theirName. Warte auf die Verbindung …"
            }
        }

        override fun onEndpointLost(endpointId: String) { asked.remove(endpointId) }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            if (peer != null && peer != endpointId) { client.rejectConnection(endpointId); return }
            state = DuoState.CONNECTING
            message = "Verbinde …"
            client.acceptConnection(endpointId, payloads)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                peer = endpointId
                try { client.stopAdvertising(); client.stopDiscovery() } catch (_: Exception) {}
                main.removeCallbacks(timeout)
                state = DuoState.CONNECTED
                message = "Verbunden."
                send(JSONObject().put("t", "hello").put("name", Palette.skin.name).put("skin", Palette.skin.id))
            } else {
                asked.remove(endpointId)
                state = DuoState.WAITING
                message = "Die Verbindung kam nicht zustande (${result.status.statusCode}). Ich suche weiter."
            }
        }

        override fun onDisconnected(endpointId: String) { if (endpointId == peer) lost() }
    }

    private val payloads = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val json = try { JSONObject(String(bytes, Charsets.UTF_8)) } catch (_: Exception) { return }
            handle(json)
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private fun handle(json: JSONObject) {
        when (json.optString("t")) {
            "hello" -> { peerName = json.optString("name", "Bluey"); peerSkin = Skins.byId(json.optString("skin")) }
            "say" -> onSay?.invoke(json.optString("text"))
            "start" -> onStart?.invoke(json.optString("topic", ""))
            "stop" -> onStop?.invoke()
        }
    }

    fun send(json: JSONObject) {
        val id = peer ?: return
        try { client.sendPayload(id, Payload.fromBytes(json.toString().toByteArray(Charsets.UTF_8))) } catch (_: Exception) {}
    }

    private fun lost() {
        val was = state == DuoState.CONNECTED
        reset()
        if (was) { message = "Die Verbindung ist weg."; onDisconnected?.invoke() }
    }

    private fun reset() {
        main.removeCallbacks(timeout)
        try { client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints() } catch (_: Exception) {}
        peer = null
        asked.clear()
        state = DuoState.OFF
        peerName = null
        peerSkin = null
    }

    fun close() {
        val was = state == DuoState.CONNECTED
        reset()
        message = ""
        if (was) onDisconnected?.invoke()
    }
}
