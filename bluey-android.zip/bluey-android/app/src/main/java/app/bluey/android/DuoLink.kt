package app.bluey.android

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

enum class DuoState { OFF, WAITING, CONNECTING, CONNECTED }

/**
 * Duo mode: two phones, each with a Bluey, side by side and connected by Bluetooth. They send each other
 * what they say as text lines (JSON, one per line). Both phones must be paired once in the Bluetooth settings.
 */
class DuoLink(private val context: Context) {
    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("7c1d0f3e-5a42-4b0c-9d2a-4b1e6f5a8c11")
    }

    private val prefs = context.getSharedPreferences("bluey", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val writer = Executors.newSingleThreadExecutor()

    var state by mutableStateOf(DuoState.OFF); private set
    var peerName by mutableStateOf<String?>(null); private set
    var peerSkin by mutableStateOf<Skin?>(null); private set
    var message by mutableStateOf(""); private set

    private var sideState by mutableStateOf(prefs.getString("duoSide", "right") ?: "right")
    /** Where the other phone stands: "left" or "right" of this one. */
    var side: String
        get() = sideState
        set(value) { sideState = value; prefs.edit().putString("duoSide", value).apply() }

    var onSay: ((String) -> Unit)? = null
    var onStart: ((String) -> Unit)? = null
    var onStop: (() -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    /** Asks for the Bluetooth permission (Android 12+); calls back with whether it was granted. */
    var requestPermission: ((Boolean) -> Unit) -> Unit = { done -> done(true) }

    private var socket: BluetoothSocket? = null
    private var server: BluetoothServerSocket? = null
    private var out: OutputStream? = null
    @Volatile private var closing = false

    private val adapter: BluetoothAdapter?
        get() = (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun allowed() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun paired(): List<BluetoothDevice> = try {
        if (allowed()) adapter?.bondedDevices?.toList() ?: emptyList() else emptyList()
    } catch (_: Exception) { emptyList() }

    private fun check(then: () -> Unit) {
        val a = adapter
        if (a == null) { message = "Dieses Handy hat kein Bluetooth."; return }
        if (!a.isEnabled) { message = "Schalte Bluetooth ein."; return }
        if (allowed()) { then(); return }
        requestPermission { granted ->
            if (granted) then() else message = "Ich brauche die Bluetooth-Erlaubnis (in den Handy-Einstellungen für Bluey)."
        }
    }

    /** This phone waits until the other one connects. */
    @SuppressLint("MissingPermission")
    fun listen() = check {
        close()
        closing = false
        state = DuoState.WAITING
        message = "Ich warte auf das andere Handy …"
        Thread {
            try {
                val s = adapter!!.listenUsingInsecureRfcommWithServiceRecord("Bluey", SERVICE_UUID)
                server = s
                val c = s.accept()
                try { s.close() } catch (_: Exception) {}
                connected(c)
            } catch (e: Exception) {
                if (!closing) main.post { state = DuoState.OFF; message = "Das Warten hat nicht geklappt." }
            }
        }.apply { isDaemon = true; start() }
    }

    /** This phone connects to a paired phone that is waiting. */
    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) = check {
        close()
        closing = false
        state = DuoState.CONNECTING
        message = "Verbinde mit ${device.name ?: "dem Handy"} …"
        Thread {
            try {
                adapter?.cancelDiscovery()
                val c = device.createInsecureRfcommSocketToServiceRecord(SERVICE_UUID)
                c.connect()
                connected(c)
            } catch (e: Exception) {
                if (!closing) main.post { state = DuoState.OFF; message = "Das hat nicht geklappt. Wartet das andere Handy schon („Warten“ gedrückt)?" }
            }
        }.apply { isDaemon = true; start() }
    }

    private fun connected(s: BluetoothSocket) {
        socket = s
        out = s.outputStream
        main.post { state = DuoState.CONNECTED; message = "Verbunden." }
        send(JSONObject().put("t", "hello").put("name", Palette.skin.name).put("skin", Palette.skin.id))
        try {
            val reader = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
            while (true) {
                val line = reader.readLine() ?: break
                val json = try { JSONObject(line) } catch (_: Exception) { continue }
                main.post { handle(json) }
            }
        } catch (_: Exception) {
        }
        main.post { lost() }
    }

    private fun handle(json: JSONObject) {
        when (json.optString("t")) {
            "hello" -> { peerName = json.optString("name", "Bluey"); peerSkin = Skins.byId(json.optString("skin")) }
            "say" -> onSay?.invoke(json.optString("text"))
            "start" -> onStart?.invoke(json.optString("topic", ""))
            "stop" -> onStop?.invoke()
        }
    }

    fun send(json: JSONObject) {
        val stream = out ?: return
        writer.execute {
            try { stream.write((json.toString() + "\n").toByteArray(Charsets.UTF_8)); stream.flush() } catch (_: Exception) { }
        }
    }

    private fun lost() {
        if (state == DuoState.OFF) return
        val wasConnected = state == DuoState.CONNECTED
        reset()
        if (wasConnected) { message = "Die Verbindung ist weg."; onDisconnected?.invoke() }
    }

    private fun reset() {
        closing = true
        try { server?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        server = null; socket = null; out = null
        state = DuoState.OFF
        peerName = null
        peerSkin = null
    }

    fun close() {
        val was = state == DuoState.CONNECTED
        reset()
        message = ""
        if (was) onDisconnected?.invoke()
    }
}
