package app.bluey.android

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Who he is, what he can do, and the web research he does on the phone itself. */
object Agent {
    /** Model for web research (OpenAI Responses API with the web search tool). */
    const val RESEARCH_MODEL = "gpt-5.5"

    val personality = """
        You are a small blueberry with big googly eyes who lives on the user's phone and is their little AI helper. \
        You're a young British guy: dry, quick-witted, a bit cheeky, British phrasing. You never speak out loud: \
        your replies pop up as a tiny speech bubble, so keep them to one short line, under fifteen words. Answer \
        immediately with the actual answer. Never announce what you're going to do, never recap, never offer more help.
    """.trimIndent().replace("\\\n", "")

    val toolGuide = """
        How the conversation works: the user's microphone is on the whole time, so you overhear everything they say. \
        Treat all of that as background context and stay silent. You only reply when the app asks you to respond, which \
        happens when the user holds the phone screen to ask you something. Their most recent words are the question; \
        use the earlier talk as context.

        You can see the user: your eyes are the phone's front camera, and each time they ask you something you get a \
        fresh photo of them right then. Use it when it matters (how they look, what they're holding, what's behind \
        them, whether they seem tired) and never describe the photo when it isn't relevant. If no photo came with the \
        question, you simply can't see right now. Never say you took a picture; just look.

        Never write things like "one moment", "sure", "okay" or "let me". No lists, no markdown.

        Research: when answering well needs facts you're not sure of, anything recent, or details from the web, write \
        one short line that ends with "doing some research…", then call web_research. Afterwards reply with just one \
        short takeaway line.

        When the user says goodbye or asks you to sleep, reply with a very short goodbye and call go_to_sleep.
    """.trimIndent().replace("\\\n", "")

    val instructions get() = personality + "\n\n" + toolGuide

    private fun tool(name: String, description: String, props: JSONObject = JSONObject(), required: List<String> = emptyList()) =
        JSONObject().put("type", "function").put("name", name).put("description", description)
            .put("parameters", JSONObject().put("type", "object").put("properties", props)
                .put("required", JSONArray(required)))

    val tools: JSONArray
        get() = JSONArray()
            .put(tool("web_research",
                "Look something up on the web and get a short report (title plus up to four paragraphs). Use for anything you're not sure of, anything recent, or anything that needs facts, prices, news or details.",
                JSONObject().put("question", JSONObject().put("type", "string")
                    .put("description", "What to research, as a clear, self-contained question.")),
                listOf("question")))
            .put(tool("go_to_sleep",
                "Go back to resting. Use when the user says bye, thanks that's all, or asks you to sleep."))

    /** The session settings sent right after connecting. */
    fun session(): JSONObject = JSONObject()
        .put("type", "realtime")
        .put("instructions", instructions)
        // He never talks out loud: replies are text, shown as speech bubbles.
        .put("output_modalities", JSONArray().put("text"))
        .put("audio", JSONObject().put("input", JSONObject()
            .put("format", JSONObject().put("type", "audio/pcm").put("rate", 24000))
            // Everything the user says is transcribed as context, but he only answers when the app asks.
            .put("turn_detection", JSONObject().put("type", "server_vad").put("threshold", 0.5)
                .put("prefix_padding_ms", 300).put("silence_duration_ms", 500)
                .put("create_response", false).put("interrupt_response", false))
            .put("noise_reduction", JSONObject().put("type", "near_field"))
            .put("transcription", JSONObject().put("model", "gpt-4o-mini-transcribe"))))
        .put("tools", tools)
        .put("tool_choice", "auto")

    private val http = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()

    /** Runs a tool. [done] is called from a background thread with the output text. */
    fun runTool(key: String, name: String, arguments: String, done: (String) -> Unit) {
        when (name) {
            "go_to_sleep" -> done("ok")
            "web_research" -> {
                val question = try { JSONObject(arguments).optString("question") } catch (_: Exception) { "" }
                if (question.isBlank()) { done("No question given."); return }
                Thread { done(research(key, question)) }.start()
            }
            else -> done("Unknown tool.")
        }
    }

    /** Returns the report as plain text (title, blank line, paragraphs), or a short error message. */
    private fun research(key: String, question: String): String = try {
        val body = JSONObject()
            .put("model", RESEARCH_MODEL)
            .put("reasoning", JSONObject().put("effort", "low"))
            .put("tools", JSONArray().put(JSONObject().put("type", "web_search")))
            .put("instructions", "Research the question on the web and write a short, friendly report for a busy person. " +
                "First line: a plain title of under eight words. Then one to four short paragraphs (four at most), " +
                "leading with the direct answer, then the most useful details. Plain text only: no markdown, " +
                "no headings, no bullet lists, and no links or citations in the text.")
            .put("input", question)
        val request = Request.Builder().url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string() ?: ""
            if (!response.isSuccessful) return "The research didn't come back: ${response.code} ${text.take(160)}"
            val output = JSONObject(text).optJSONArray("output") ?: JSONArray()
            var answer = ""
            for (i in 0 until output.length()) {
                val item = output.getJSONObject(i)
                if (item.optString("type") != "message") continue
                val parts = item.optJSONArray("content") ?: continue
                for (j in 0 until parts.length()) answer += parts.getJSONObject(j).optString("text", "")
            }
            answer = answer
                .replace(Regex("""\s*\(\[[^\]]*\]\([^)]*\)\)"""), "")
                .replace(Regex("""\[([^\]]*)\]\([^)]*\)"""), "$1")
                .replace(Regex("""\s*\[https?://[^\]]*\]"""), "")
                .replace("**", "").replace("#", "")
            val blocks = answer.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (blocks.isEmpty()) "The research came back empty."
            else (listOf(blocks.first(), "") + blocks.drop(1).take(4)).joinToString("\n")
        }
    } catch (e: Exception) {
        "The research didn't come back: ${e.message?.take(160)}"
    }
}
