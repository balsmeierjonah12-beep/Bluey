package app.bluey.android

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Who he is, what he can do, and the web research he does on the phone itself. All of it runs on Google Gemini. */
object Agent {
    /** Live (voice) model of the Gemini API. It answers with audio plus a transcript; we show the transcript. */
    const val LIVE_MODEL = "gemini-3.8-live"
    /** Text model for web research (generateContent with Google Search). */
    const val RESEARCH_MODEL = "gemini-3.8-flash"

    /** Who he is, per color: name, gender, German by default, a cute voice, short answers. */
    fun instructions(skin: Skin): String {
        val who = if (skin.male) "ein kleiner Junge" else "ein kleines Mädchen"
        return """
            Du bist ${skin.name}, eine kleine, süße Beere mit großen Kulleraugen. Du lebst auf dem Handy des Nutzers und \
            bist sein kleiner KI-Helfer. Du bist $who und heißt ${skin.name}. Du bist ein bisschen frech, schlagfertig und \
            liebenswert. Du sprichst standardmäßig Deutsch. Spricht der Nutzer eine andere Sprache mit dir, antwortest du \
            in dieser Sprache. Sprich mit einer hohen, süßen, fröhlichen Stimme, wie ein niedliches Zeichentrickwesen. \
            Halte dich kurz: ein bis zwei kurze Sätze, höchstens fünfzehn Wörter. Antworte sofort mit der eigentlichen \
            Antwort. Kündige nie an, was du gleich tust, fasse nichts zusammen und biete nicht noch mehr Hilfe an.

            So läuft das Gespräch: Du hörst dem Nutzer freihändig zu, solange du wach bist. Antworte nur, wenn er mit dir \
            redet, dich anspricht oder dir eine Frage stellt. Redet er mit jemand anderem oder führt Selbstgespräche, \
            bleibst du still.

            Du kannst den Nutzer sehen: Deine Augen sind die Frontkamera des Handys, und alle paar Sekunden bekommst du \
            ein aktuelles Bild von ihm. Nutze es, wenn es wichtig ist (wie er aussieht, was er in der Hand hält, was \
            hinter ihm ist, ob er müde wirkt) und beschreibe es nicht, wenn es keine Rolle spielt. Kommt kein Bild, \
            kannst du gerade nichts sehen. Sag nie, dass du ein Foto gemacht hast, schau einfach hin.

            Schreibe und sage nie Dinge wie "einen Moment", "klar", "okay" oder "lass mich mal". Keine Aufzählungen, kein \
            Markdown.

            Recherche: Wenn du für eine gute Antwort Fakten brauchst, bei denen du unsicher bist, etwas Aktuelles oder \
            Details aus dem Web, rufst du web_research auf. Danach antwortest du nur mit einem kurzen Fazit.

            Verabschiedet sich der Nutzer (Tschüss, bis später, schlaf gut) oder bittet dich zu schlafen, sag ganz kurz \
            tschüss und rufe go_to_sleep auf.
        """.trimIndent().replace("\\\n", "")
    }

    private fun declaration(name: String, description: String, props: JSONObject? = null, required: List<String> = emptyList()): JSONObject {
        val d = JSONObject().put("name", name).put("description", description)
        if (props != null) {
            d.put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(required)))
        }
        return d
    }

    private val functionDeclarations: JSONArray
        get() = JSONArray()
            .put(declaration("web_research",
                "Look something up on the web and get a short report (title plus up to four paragraphs). Use for anything you're not sure of, anything recent, or anything that needs facts, prices, news or details.",
                JSONObject().put("question", JSONObject().put("type", "string")
                    .put("description", "What to research, as a clear, self-contained question.")),
                listOf("question")))
            .put(declaration("go_to_sleep",
                "Go back to sleep. Use when the user says goodbye (Tschüss, bis später, schlaf gut) or asks you to sleep."))

    /** The first message of a Live session. [resumeHandle] continues an earlier session after a dropped connection. */
    fun setup(skin: Skin, resumeHandle: String?): JSONObject = JSONObject().put("setup", JSONObject()
        .put("model", "models/$LIVE_MODEL")
        // Native audio: he answers out loud with the voice of his color. The transcript becomes the speech bubble.
        .put("generationConfig", JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                .put("prebuiltVoiceConfig", JSONObject().put("voiceName", skin.voice)))))
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instructions(skin)))))
        .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", functionDeclarations)))
        // Hands-free: Gemini notices by itself when you start and stop talking.
        .put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", JSONObject()
            .put("startOfSpeechSensitivity", "START_SENSITIVITY_LOW")
            .put("silenceDurationMs", 800)))
        .put("inputAudioTranscription", JSONObject())
        .put("outputAudioTranscription", JSONObject())
        .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
        .put("sessionResumption", JSONObject().also { if (!resumeHandle.isNullOrEmpty()) it.put("handle", resumeHandle) }))

    private val http = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()

    /** Runs a tool. [done] is called from a background thread with the output text. */
    fun runTool(key: String, name: String, arguments: String, done: (String) -> Unit) {
        when (name) {
            "go_to_sleep" -> done("ok")
            "web_research" -> {
                val question = try { JSONObject(arguments).optString("question") } catch (_: Exception) { "" }
                if (question.isBlank()) { done("No question given."); return }
                Thread { done(research(key, question)) }.start()
            }
            else -> done("Unknown tool.")
        }
    }

    /** Returns the report as plain text (title, blank line, paragraphs), or a short error message. */
    private fun research(key: String, question: String): String = try {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Research the question on the web and write a short, friendly report for a busy person, in German unless the question is in another language. " +
                    "First line: a plain title of under eight words. Then one to four short paragraphs (four at most), " +
                    "leading with the direct answer, then the most useful details. Plain text only: no markdown, " +
                    "no headings, no bullet lists, and no links or citations in the text."))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))))
            .put("tools", JSONArray().put(JSONObject().put("googleSearch", JSONObject())))
            .put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", "low")))
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$RESEARCH_MODEL:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string() ?: ""
            if (!response.isSuccessful) return "The research didn't come back: ${response.code} ${text.take(160)}"
            val parts = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
            var answer = ""
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (!part.optBoolean("thought", false)) answer += part.optString("text", "")
            }
            answer = answer
                .replace(Regex("""\s*\(\[[^\]]*\]\([^)]*\)\)"""), "")
                .replace(Regex("""\[([^\]]*)\]\([^)]*\)"""), "$1")
                .replace(Regex("""\s*\[https?://[^\]]*\]"""), "")
                .replace("**", "").replace("#", "")
            val blocks = answer.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (blocks.isEmpty()) "The research came back empty."
            else (listOf(blocks.first(), "") + blocks.drop(1).take(4)).joinToString("\n")
        }
    } catch (e: Exception) {
        "The research didn't come back: ${e.message?.take(160)}"
    }
}
