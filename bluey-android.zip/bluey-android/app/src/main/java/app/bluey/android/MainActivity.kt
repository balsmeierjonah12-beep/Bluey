package app.bluey.android

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.OrientationEventListener
import android.view.Surface
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

/**
 * Bluey as a stand-alone, hands-free AI helper: no computer needed. Say "Hey Bluey" (or Pinky, Greeny …)
 * and talk. Camera and mic are his eyes and ears, and he answers out loud in German.
 */
class MainActivity : ComponentActivity() {
    private lateinit var settings: Settings
    private lateinit var camera: CameraWatcher
    private lateinit var live: LiveVoice
    private lateinit var store: SessionStore
    private lateinit var wake: WakeWord
    private lateinit var voice: VoiceID
    private val animator = FaceAnimator()
    private val caption = mutableStateOf("")
    private val showApp = mutableStateOf(false)
    private val openSettings = mutableStateOf(false)
    private val main = Handler(Looper.getMainLooper())
    private val clearCaption = Runnable { caption.value = "" }
    private var micCallback: ((Boolean) -> Unit)? = null
    private var orientation: OrientationEventListener? = null
    private var visible = false

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (has(Manifest.permission.CAMERA) && live.state != LiveVoice.State.ASLEEP) camera.start(this)
        micCallback?.invoke(has(Manifest.permission.RECORD_AUDIO))
        micCallback = null
    }

    private fun has(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    /** Listen for "Hey <name>" only while he sleeps and the app is open. */
    private fun syncWake() {
        val should = visible && voice.enrolling == null && settings.wakeWord && settings.hasKey && has(Manifest.permission.RECORD_AUDIO) &&
            live.state == LiveVoice.State.ASLEEP
        if (should) wake.start() else wake.stop()
    }

    private val wakeCheck = object : Runnable {
        override fun run() {
            syncWake()
            main.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        settings = Settings(this)
        camera = CameraWatcher(this)
        store = SessionStore(this)
        voice = VoiceID(VoiceProfiles(this))
        live = LiveVoice(this, settings, camera, voice)
        wake = WakeWord(this)
        wire()

        orientation = object : OrientationEventListener(this) {
            override fun onOrientationChanged(degrees: Int) {
                if (degrees == ORIENTATION_UNKNOWN) return
                camera.setRotation(when (degrees) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                })
            }
        }

        setContent {
            RootView(live, store, settings, camera, voice, animator, caption.value, showApp.value, openSettings.value) {
                showApp.value = it
                if (!it) openSettings.value = false
            }
        }

        // Camera and microphone, asked once up front.
        val missing = mutableListOf<String>()
        if (!has(Manifest.permission.CAMERA)) missing.add(Manifest.permission.CAMERA)
        if (!has(Manifest.permission.RECORD_AUDIO)) missing.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isNotEmpty()) permissions.launch(missing.toTypedArray())
    }

    override fun onStart() {
        super.onStart()
        visible = true
        // The camera only runs while he is awake: asleep, he just snoozes.
        if (has(Manifest.permission.CAMERA) && live.state != LiveVoice.State.ASLEEP) camera.start(this)
        orientation?.takeIf { it.canDetectOrientation() }?.enable()
        main.removeCallbacks(wakeCheck)
        main.post(wakeCheck)
    }

    override fun onStop() {
        super.onStop()
        visible = false
        main.removeCallbacks(wakeCheck)
        wake.stop()
        camera.stop()
        orientation?.disable()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) live.sleep()
    }

    private fun wire() {
        wake.variants = { settings.skin.wakeVariants }
        wake.onWake = { live.wake() }
        live.requestMic = { done ->
            if (has(Manifest.permission.RECORD_AUDIO)) done(true) else {
                micCallback = done
                permissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            }
        }
        live.onNeedKey = { openSettings.value = true; showApp.value = true }
        live.onSessionStart = {
            wake.stop()
            store.start()
            SessionService.start(this, settings.skin.name)
        }
        live.onSessionEnd = { store.end(); SessionService.stop(this) }
        live.onUserTurn = { item, asked -> store.placeholder(item, asked) }
        live.onUserWords = { item, text, asked -> store.heard(item, text, asked) }
        live.onReply = { store.reply(it) }
        live.onReport = { store.report(it) }
        live.onCaption = { text, finished ->
            main.removeCallbacks(clearCaption)
            caption.value = text
            // The bubble stays a while after he's done, longer for longer lines.
            if (finished) main.postDelayed(clearCaption, 4000L + text.length * 60L)
        }
        live.onStateChange = { state ->
            when (state) {
                LiveVoice.State.ASLEEP -> {
                    animator.awake = false; animator.localMood = Mood.RESTING  // eyes shut, little z's
                    camera.stop()
                    main.postDelayed({ syncWake() }, 800)
                }
                LiveVoice.State.WAKING -> {
                    animator.awake = true; animator.localMood = Mood.HAPPY; wake.stop()
                    if (has(Manifest.permission.CAMERA)) camera.start(this)
                }
                LiveVoice.State.LISTENING -> { animator.awake = true; animator.localMood = null }
                LiveVoice.State.ASKING -> { animator.awake = true; animator.localMood = Mood.LISTENING }
                LiveVoice.State.THINKING -> animator.localMood = Mood.THINKING
                LiveVoice.State.SPEAKING -> animator.localMood = Mood.TALKING
            }
        }
        // He always looks at you: the camera drives his eyes (and a smile makes him happy).
        camera.onFace = { face -> if (face != null) animator.receive(face, System.nanoTime() / 1e9) }
        // Something is shown to him or moves in front of the camera: he looks at it and hops.
        camera.onMotion = { strength, gx, gy ->
            if (live.state != LiveVoice.State.ASLEEP) animator.react(strength.toDouble(), gx.toDouble(), gy.toDouble(), System.nanoTime() / 1e9)
        }
        animator.localTalk = { live.level }
        animator.localMood = Mood.RESTING  // starts asleep: eyes shut, little z's
    }
}

@Composable
fun RootView(
    live: LiveVoice, store: SessionStore, settings: Settings, camera: CameraWatcher, voice: VoiceID, animator: FaceAnimator,
    caption: String, showApp: Boolean, startOnSettings: Boolean, setShowApp: (Boolean) -> Unit,
) {
    BackHandler(showApp) { setShowApp(false) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Tap: wake him up (or a little boop when he's awake). Double tap: send him back to sleep.
        // Saying "Hey <name>" wakes him too, without touching.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                detectTapGestures(
                    onTap = { if (live.state == LiveVoice.State.ASLEEP) live.wake() else animator.boop() },
                    onDoubleTap = { if (live.state == LiveVoice.State.ASLEEP) live.wake() else live.sleep() },
                )
            },
        ) { FaceView(animator) }

        ModeIndicator(
            live.state,
            if (settings.wakeWord && settings.hasKey) "Sag „Hey ${Palette.skin.name}“" else null,
        )
        CaptionBubble(caption)
        CameraDot(camera)
        SoundButton(live)

        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 62.dp).size(44.dp).clip(CircleShape).clickable { setShowApp(true) },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.GridView, "Menü", Modifier.size(14.dp), tint = Color.White.copy(alpha = 0.35f))
            }
        }

        AnimatedVisibility(showApp, enter = fadeIn(), exit = fadeOut()) {
            BlueyAppView(store, settings, voice, live.state != LiveVoice.State.ASLEEP, startOnSettings) { setShowApp(false) }
        }
        // No key yet: he asks for one before anything else.
        AnimatedVisibility(!settings.hasKey, enter = fadeIn(), exit = fadeOut()) { KeyView(settings) }
    }
}
