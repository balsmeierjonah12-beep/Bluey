package app.bluey.android

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material3.Icon
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var link: MacLink
    private lateinit var live: LiveVoice
    private lateinit var store: SessionStore
    private lateinit var recorder: ChunkRecorder
    private val animator = FaceAnimator()
    private var micCallback: ((Boolean) -> Unit)? = null

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        micCallback?.invoke(result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        micCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val audioRoot = java.io.File(filesDir, "audio")
        recorder = ChunkRecorder(audioRoot)
        link = MacLink(this)
        live = LiveVoice(this, recorder)
        store = SessionStore(this)
        wire(audioRoot)

        setContent { RootView(link, live, store, animator, audioRoot) }
    }

    override fun onStart() {
        super.onStart()
        link.start()
    }

    override fun onStop() {
        super.onStop()
        // While a session runs, the link to the Mac stays up (tools and captions need it).
        if (live.state == LiveVoice.State.ASLEEP) link.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) live.sleep()
    }

    private fun wire(audioRoot: java.io.File) {
        live.requestMic = { done ->
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted) done(true) else {
                micCallback = done
                val wanted = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
                permissions.launch(wanted.toTypedArray())
            }
        }
        live.requestToken = { done -> link.request(Packet(command = "realtimeToken")) { done(it?.text) } }
        live.runTool = { name, arguments, done ->
            link.request(Packet(command = "tool", tool = name, text = arguments)) { reply ->
                done(reply?.text ?: "The Mac didn't answer.", reply?.image)
            }
        }
        live.onSessionStart = {
            store.start()
            store.currentID?.let { recorder.start(it) }
            SessionService.start(this)
        }
        live.onSessionEnd = { store.end(); SessionService.stop(this) }
        live.resumeContext = { store.recentText() }
        recorder.onChunk = { chunk ->
            store.addPending(chunk.sessionID, chunk.index, chunk.startedMs)
            NotesSync.upload(audioRoot, chunk.sessionID, chunk.index, chunk.startedMs, store, link)
        }
        store.onSync = { sessions -> NotesSync.send(sessions, store, link) }
        live.onUserTurn = { item, asked -> store.placeholder(item, asked) }
        live.onUserWords = { item, text, asked -> store.heard(item, text, asked) }
        live.onReply = { store.reply(it) }
        live.onReport = { store.report(it) }
        live.onCaption = { text, finished -> link.send(Packet(command = if (finished) "captionDone" else "caption", text = text)) }
        live.onStateChange = { state ->
            when (state) {
                LiveVoice.State.ASLEEP -> { animator.awake = false; animator.localMood = null; link.send(Packet(command = "asleep")) }
                LiveVoice.State.WAKING -> { animator.awake = true; animator.localMood = Mood.HAPPY }
                LiveVoice.State.LISTENING -> { animator.awake = true; animator.localMood = null; link.send(Packet(command = "awake")) }
                LiveVoice.State.ASKING -> { animator.awake = true; animator.localMood = Mood.LISTENING; link.send(Packet(command = "awake")) }
                LiveVoice.State.THINKING -> animator.localMood = Mood.THINKING
                LiveVoice.State.SPEAKING -> animator.localMood = Mood.TALKING
            }
        }
        link.onFace = { face -> animator.receive(face, System.nanoTime() / 1e9) }
        link.onCommand = { command ->
            when (command) {
                "wake" -> live.wake()
                "sleep" -> live.sleep()
            }
        }
        animator.localTalk = { live.level }
    }
}

@Composable
fun RootView(link: MacLink, live: LiveVoice, store: SessionStore, animator: FaceAnimator, audioRoot: java.io.File) {
    var showApp by remember { mutableStateOf(false) }
    var showPairing by remember { mutableStateOf(true) }
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(link.connected) {
        if (link.connected) {
            showPairing = false
            NotesSync.retryPending(audioRoot, store, link)
            store.resyncRecent()
        }
    }
    BackHandler(showApp) { showApp = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Double tap: wake up / back to follow mode. Press and hold: ask him something, let go and he answers.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                var holdJob: Job? = null
                var holding = false
                detectTapGestures(
                    onDoubleTap = { live.toggle() },
                    onPress = {
                        holdJob = scope.launch {
                            delay(300)  // a quick tap isn't a hold
                            holding = true
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            live.beginAsk()
                        }
                        tryAwaitRelease()
                        holdJob?.cancel()
                        if (holding) {
                            holding = false
                            live.endAsk()
                        }
                    },
                )
            },
        ) { FaceView(animator) }

        ModeIndicator(live.state)
        SoundButton(link, live)

        // Bluey's app: sessions, transcripts.
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 62.dp).size(44.dp).clip(CircleShape).clickable { showApp = true },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.GridView, "Open Bluey", Modifier.size(14.dp), tint = Color.White.copy(alpha = 0.35f))
            }
        }

        AnimatedVisibility(showPairing && !link.connected, enter = fadeIn(), exit = fadeOut()) {
            PairingView { showPairing = false }
        }
        AnimatedVisibility(showApp, enter = fadeIn(), exit = fadeOut()) {
            BlueyAppView(store) { showApp = false }
        }
    }
}
