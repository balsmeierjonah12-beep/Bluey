package app.bluey.android

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.OrientationEventListener
import android.view.Surface
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Bluey as a stand-alone AI helper: no computer needed. Camera and mic are his eyes and ears. */
class MainActivity : ComponentActivity() {
    private lateinit var settings: Settings
    private lateinit var camera: CameraWatcher
    private lateinit var live: LiveVoice
    private lateinit var store: SessionStore
    private val animator = FaceAnimator()
    private val caption = mutableStateOf("")
    private val showApp = mutableStateOf(false)
    private val main = Handler(Looper.getMainLooper())
    private val clearCaption = Runnable { caption.value = "" }
    private var micCallback: ((Boolean) -> Unit)? = null
    private var orientation: OrientationEventListener? = null

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (has(Manifest.permission.CAMERA)) camera.start(this)
        micCallback?.invoke(has(Manifest.permission.RECORD_AUDIO))
        micCallback = null
    }

    private fun has(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        settings = Settings(this)
        camera = CameraWatcher(this)
        store = SessionStore(this)
        live = LiveVoice(this, settings, camera)
        wire()

        orientation = object : OrientationEventListener(this) {
            override fun onOrientationChanged(degrees: Int) {
                if (degrees == ORIENTATION_UNKNOWN) return
                camera.setRotation(when (degrees) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                })
            }
        }

        setContent {
            RootView(live, store, settings, camera, animator, caption.value, showApp.value, { showApp.value = it })
        }

        // Camera and microphone, asked once up front.
        val missing = mutableListOf<String>()
        if (!has(Manifest.permission.CAMERA)) missing.add(Manifest.permission.CAMERA)
        if (!has(Manifest.permission.RECORD_AUDIO)) missing.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isNotEmpty()) permissions.launch(missing.toTypedArray())
    }

    override fun onStart() {
        super.onStart()
        if (has(Manifest.permission.CAMERA)) camera.start(this)
        orientation?.takeIf { it.canDetectOrientation() }?.enable()
    }

    override fun onStop() {
        super.onStop()
        camera.stop()
        orientation?.disable()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) live.sleep()
    }

    private fun wire() {
        live.requestMic = { done ->
            if (has(Manifest.permission.RECORD_AUDIO)) done(true) else {
                micCallback = done
                permissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            }
        }
        live.onNeedKey = { showApp.value = true }
        live.onSessionStart = {
            store.start()
            SessionService.start(this)
        }
        live.onSessionEnd = { store.end(); SessionService.stop(this) }
        live.resumeContext = { store.recentText() }
        live.onUserTurn = { item, asked -> store.placeholder(item, asked) }
        live.onUserWords = { item, text, asked -> store.heard(item, text, asked) }
        live.onReply = { store.reply(it) }
        live.onReport = { store.report(it) }
        live.onCaption = { text, finished ->
            main.removeCallbacks(clearCaption)
            caption.value = text
            // The bubble stays a while after he's done, longer for longer lines.
            if (finished) main.postDelayed(clearCaption, 4000L + text.length * 60L)
        }
        live.onStateChange = { state ->
            when (state) {
                LiveVoice.State.ASLEEP -> { animator.awake = false; animator.localMood = null }
                LiveVoice.State.WAKING -> { animator.awake = true; animator.localMood = Mood.HAPPY }
                LiveVoice.State.LISTENING -> { animator.awake = true; animator.localMood = null }
                LiveVoice.State.ASKING -> { animator.awake = true; animator.localMood = Mood.LISTENING }
                LiveVoice.State.THINKING -> animator.localMood = Mood.THINKING
                LiveVoice.State.SPEAKING -> animator.localMood = Mood.TALKING
            }
        }
        // He always looks at you: the camera drives his eyes (and a smile makes him happy).
        camera.onFace = { face -> if (face != null) animator.receive(face, System.nanoTime() / 1e9) }
        animator.localTalk = { live.level }
    }
}

@Composable
fun RootView(
    live: LiveVoice, store: SessionStore, settings: Settings, camera: CameraWatcher, animator: FaceAnimator,
    caption: String, showApp: Boolean, setShowApp: (Boolean) -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    BackHandler(showApp) { setShowApp(false) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Double tap: wake up / go to sleep. Press and hold: ask him something, let go and he answers.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                var holdJob: Job? = null
                var holding = false
                detectTapGestures(
                    onDoubleTap = { live.toggle() },
                    onPress = {
                        holdJob = scope.launch {
                            delay(300)  // a quick tap isn't a hold
                            holding = true
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            live.beginAsk()
                        }
                        tryAwaitRelease()
                        holdJob?.cancel()
                        if (holding) {
                            holding = false
                            live.endAsk()
                        }
                    },
                )
            },
        ) { FaceView(animator) }

        ModeIndicator(live.state)
        CaptionBubble(caption)
        CameraDot(camera)
        SoundButton(live)

        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 62.dp).size(44.dp).clip(CircleShape).clickable { setShowApp(true) },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.GridView, "Open Bluey", Modifier.size(14.dp), tint = Color.White.copy(alpha = 0.35f))
            }
        }

        AnimatedVisibility(showApp, enter = fadeIn(), exit = fadeOut()) {
            BlueyAppView(store, settings) { setShowApp(false) }
        }
        // No key yet: he asks for one before anything else.
        AnimatedVisibility(!settings.hasKey, enter = fadeIn(), exit = fadeOut()) { KeyView(settings) }
    }
}
