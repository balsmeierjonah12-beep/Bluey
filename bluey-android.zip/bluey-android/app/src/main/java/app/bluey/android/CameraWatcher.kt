package app.bluey.android

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * His eyes: the front camera, always on while the app is open. It finds your face so he can look at you,
 * and can hand over a fresh photo of you for the AI. Nothing is shown on screen and nothing leaves the phone
 * except photos that are sent along with a question (if that is switched on).
 */
class CameraWatcher(private val context: Context) {
    var running by mutableStateOf(false); private set
    var faceVisible by mutableStateOf(false); private set

    /** Called on the main thread with where your face is (and whether you smile), or null when it's gone. */
    var onFace: ((FaceState?) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build()
    )
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    @Volatile private var snapshotCallback: ((String?) -> Unit)? = null
    private var lastFaceAt = 0L
    @Volatile private var wanted = false

    /** Something moved in front of the camera (strength 0…1, and where he should look: gazeX, gazeY). Main thread. */
    var onMotion: ((Float, Float, Float) -> Unit)? = null

    private var liveInterval = 1000L
    @Volatile private var liveCallback: ((String) -> Unit)? = null
    private var lastLive = 0L
    private var prevGrid: IntArray? = null
    private var lastMotion = 0L

    /** Live video for the AI: a small JPEG (base64) about every [intervalMs] while the camera runs. Called on a background thread. */
    fun startLive(intervalMs: Long, callback: (String) -> Unit) { liveInterval = intervalMs; liveCallback = callback }

    fun stopLive() { liveCallback = null }

    fun start(owner: LifecycleOwner) {
        wanted = true
        if (running) return
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (!wanted) return@addListener
            try {
                val p = future.get()
                provider = p
                val a = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                a.setAnalyzer(executor) { proxy -> analyze(proxy) }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, a)
                analysis = a
                running = true
            } catch (e: Exception) {
                running = false
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stop() {
        wanted = false
        provider?.unbindAll()
        analysis = null
        running = false
        faceVisible = false
    }

    /** Keeps the image upright when the phone is flipped between the two landscape directions. */
    fun setRotation(surfaceRotation: Int) { analysis?.targetRotation = surfaceRotation }

    /** A fresh JPEG (base64) of what the camera sees right now, or null if the camera isn't running. */
    fun snapshot(done: (String?) -> Unit) {
        if (!running) { done(null); return }
        snapshotCallback = done
        main.postDelayed({
            val cb = snapshotCallback
            if (cb === done) { snapshotCallback = null; done(null) }
        }, 1500)
    }

    /** Every frame must be closed, whatever goes wrong, or the camera stream stalls and his eyes freeze. */
    private fun analyze(proxy: ImageProxy) {
        try {
            analyzeFrame(proxy)
        } catch (e: Exception) {
            try { proxy.close() } catch (_: Exception) {}
        }
    }

    @OptIn(ExperimentalGetImage::class)
    private fun analyzeFrame(proxy: ImageProxy) {
        snapshotCallback?.let { cb ->
            snapshotCallback = null
            cb(encode(proxy, 768, 70))
        }
        val clock = SystemClock.elapsedRealtime()
        liveCallback?.let { cb ->
            if (clock - lastLive >= liveInterval) {
                lastLive = clock
                encode(proxy, 384, 55)?.let(cb)
            }
        }
        detectMotion(proxy, clock)
        val media = proxy.image
        if (media == null) { proxy.close(); return }
        val rotation = proxy.imageInfo.rotationDegrees
        val upright = rotation % 180 == 0
        val w = (if (upright) proxy.width else proxy.height).toFloat()
        val h = (if (upright) proxy.height else proxy.width).toFloat()
        detector.process(InputImage.fromMediaImage(media, rotation))
            .addOnSuccessListener { faces ->
                val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                if (face == null) {
                    if (System.currentTimeMillis() - lastFaceAt > 1500 && faceVisible) {
                        faceVisible = false
                        onFace?.invoke(null)
                    }
                } else {
                    lastFaceAt = System.currentTimeMillis()
                    val cx = face.boundingBox.exactCenterX() / w
                    val cy = face.boundingBox.exactCenterY() / h
                    // The front camera image isn't mirrored, so flip x: if you're to the right of the phone, he looks right.
                    val gx = ((0.5f - cx) * 2f * 1.6f).coerceIn(-1f, 1f).toDouble()
                    val gy = ((cy - 0.5f) * 2f * 1.4f).coerceIn(-1f, 1f).toDouble()
                    val smiling = (face.smilingProbability ?: 0f) > 0.75f
                    faceVisible = true
                    onFace?.invoke(FaceState(gx, gy, if (smiling) Mood.HAPPY else Mood.LISTENING))
                }
            }
            .addOnCompleteListener { proxy.close() }
    }

    /** Cheap motion detection on a 40×30 grid of brightness values: shows him when something is held up or moves. */
    private fun detectMotion(proxy: ImageProxy, clock: Long) {
        try {
            val plane = proxy.planes[0]
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val w = proxy.width
            val h = proxy.height
            val gw = 40
            val gh = 30
            val grid = IntArray(gw * gh)
            for (gy in 0 until gh) {
                val y = min(h - 1, gy * h / gh)
                for (gx in 0 until gw) {
                    val x = min(w - 1, gx * w / gw)
                    grid[gy * gw + gx] = buffer.get(y * rowStride + x).toInt() and 0xFF
                }
            }
            val prev = prevGrid
            prevGrid = grid
            if (prev == null) return
            var changed = 0
            var sx = 0.0
            var sy = 0.0
            for (i in grid.indices) {
                if (abs(grid[i] - prev[i]) > 28) { changed += 1; sx += i % gw; sy += i / gw }
            }
            val strength = changed / grid.size.toFloat()
            if (strength < 0.12f || clock - lastMotion < 2000) return
            lastMotion = clock
            val nx = ((sx / changed + 0.5) / gw).toFloat()
            val ny = ((sy / changed + 0.5) / gh).toFloat()
            // Turn the sensor position upright, then mirror like the face (front camera).
            val (ux, uy) = when (proxy.imageInfo.rotationDegrees) {
                90 -> (1 - ny) to nx
                180 -> (1 - nx) to (1 - ny)
                270 -> ny to (1 - nx)
                else -> nx to ny
            }
            val gx = ((0.5f - ux) * 2f * 1.6f).coerceIn(-1f, 1f)
            val gy = ((uy - 0.5f) * 2f * 1.4f).coerceIn(-1f, 1f)
            main.post { onMotion?.invoke(min(1f, strength * 2f), gx, gy) }
        } catch (_: Exception) {
        }
    }

    private fun encode(proxy: ImageProxy, maxSide: Int, quality: Int): String? = try {
        var bitmap = proxy.toBitmap()
        val matrix = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        val longest = max(bitmap.width, bitmap.height)
        if (longest > maxSide) {
            val s = maxSide.toFloat() / longest
            bitmap = Bitmap.createScaledBitmap(bitmap, (bitmap.width * s).toInt(), (bitmap.height * s).toInt(), true)
        }
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (e: Exception) {
        null
    }
}
