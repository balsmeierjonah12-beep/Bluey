package app.bluey.android

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * His eyes: the front camera, always on while the app is open. It finds your face so he can look at you,
 * and can hand over a fresh photo of you for the AI. Nothing is shown on screen and nothing leaves the phone
 * except photos that are sent along with a question (if that is switched on).
 */
class CameraWatcher(private val context: Context) {
    var running by mutableStateOf(false); private set
    var faceVisible by mutableStateOf(false); private set

    /** Called on the main thread with where your face is (and whether you smile), or null when it's gone. */
    var onFace: ((FaceState?) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build()
    )
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    @Volatile private var snapshotCallback: ((String?) -> Unit)? = null
    private var lastFaceAt = 0L

    fun start(owner: LifecycleOwner) {
        if (running) return
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val a = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                a.setAnalyzer(executor) { proxy -> analyze(proxy) }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, a)
                analysis = a
                running = true
            } catch (e: Exception) {
                running = false
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stop() {
        provider?.unbindAll()
        analysis = null
        running = false
        faceVisible = false
    }

    /** Keeps the image upright when the phone is flipped between the two landscape directions. */
    fun setRotation(surfaceRotation: Int) { analysis?.targetRotation = surfaceRotation }

    /** A fresh JPEG (base64) of what the camera sees right now, or null if the camera isn't running. */
    fun snapshot(done: (String?) -> Unit) {
        if (!running) { done(null); return }
        snapshotCallback = done
        main.postDelayed({
            val cb = snapshotCallback
            if (cb === done) { snapshotCallback = null; done(null) }
        }, 1500)
    }

    @OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        snapshotCallback?.let { cb ->
            snapshotCallback = null
            cb(encode(proxy))
        }
        val media = proxy.image
        if (media == null) { proxy.close(); return }
        val rotation = proxy.imageInfo.rotationDegrees
        val upright = rotation % 180 == 0
        val w = (if (upright) proxy.width else proxy.height).toFloat()
        val h = (if (upright) proxy.height else proxy.width).toFloat()
        detector.process(InputImage.fromMediaImage(media, rotation))
            .addOnSuccessListener { faces ->
                val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                if (face == null) {
                    if (System.currentTimeMillis() - lastFaceAt > 1500 && faceVisible) {
                        faceVisible = false
                        onFace?.invoke(null)
                    }
                } else {
                    lastFaceAt = System.currentTimeMillis()
                    val cx = face.boundingBox.exactCenterX() / w
                    val cy = face.boundingBox.exactCenterY() / h
                    // The front camera image isn't mirrored, so flip x: if you're to the right of the phone, he looks right.
                    val gx = ((0.5f - cx) * 2f * 1.6f).coerceIn(-1f, 1f).toDouble()
                    val gy = ((cy - 0.5f) * 2f * 1.4f).coerceIn(-1f, 1f).toDouble()
                    val smiling = (face.smilingProbability ?: 0f) > 0.75f
                    faceVisible = true
                    onFace?.invoke(FaceState(gx, gy, if (smiling) Mood.HAPPY else Mood.LISTENING))
                }
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun encode(proxy: ImageProxy): String? = try {
        var bitmap = proxy.toBitmap()
        val matrix = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        val longest = max(bitmap.width, bitmap.height)
        if (longest > 768) {
            val s = 768f / longest
            bitmap = Bitmap.createScaledBitmap(bitmap, (bitmap.width * s).toInt(), (bitmap.height * s).toInt(), true)
        }
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (e: Exception) {
        null
    }
}
