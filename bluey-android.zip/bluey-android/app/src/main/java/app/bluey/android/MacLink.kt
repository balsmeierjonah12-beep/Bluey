package app.bluey.android

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.UUID

/** Finds the Mac app on the local network (NSD / Bonjour) and keeps one connection open. */
class MacLink(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("bluey", Context.MODE_PRIVATE)
    private val nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = app.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val main = Handler(Looper.getMainLooper())

    var connected by mutableStateOf(false); private set
    var macName by mutableStateOf<String?>(null); private set
    var currentMac by mutableStateOf<String?>(null); private set
    var preferredMac by mutableStateOf(prefs.getString("preferredMac", null)); private set
    val macs = mutableStateListOf<String>()

    var onCommand: ((String) -> Unit)? = null
    var onFace: ((FaceState) -> Unit)? = null

    private data class Found(val name: String, var host: String? = null, var port: Int = 0)
    private val found = LinkedHashMap<String, Found>()
    private val resolveQueue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    private var listener: NsdManager.DiscoveryListener? = null
    private var multicast: WifiManager.MulticastLock? = null
    private var link: LineConnection? = null
    private var retry: Runnable? = null
    private val waiting = HashMap<String, (Packet?) -> Unit>()

    fun start() {
        if (listener != null) return
        multicast = wifi.createMulticastLock("bluey").apply { setReferenceCounted(false); acquire() }
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { main.post { restart() } }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onServiceFound(info: NsdServiceInfo) {
                main.post { resolveQueue.add(info); resolveNext() }
            }
            override fun onServiceLost(info: NsdServiceInfo) {
                main.post {
                    found.remove(info.serviceName)
                    macs.remove(info.serviceName)
                    if (currentMac == info.serviceName) link?.cancel()
                }
            }
        }
        listener = l
        nsd.discoverServices(GOOGLY_SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        retry?.let { main.removeCallbacks(it) }
        listener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listener = null
        multicast?.let { if (it.isHeld) it.release() }
        multicast = null
        link?.cancel()
        link = null
        connected = false
        found.clear(); macs.clear(); resolveQueue.clear(); resolving = false
    }

    private fun restart() {
        stop()
        scheduleRetry()
    }

    private fun scheduleRetry() {
        retry?.let { main.removeCallbacks(it) }
        val r = Runnable { if (listener == null) start() else connectIfNeeded() }
        retry = r
        main.postDelayed(r, 1500)
    }

    @Suppress("DEPRECATION")
    private fun resolveNext() {
        if (resolving) return
        val info = resolveQueue.removeFirstOrNull() ?: return
        resolving = true
        nsd.resolveService(info, object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                main.post { resolving = false; resolveNext() }
            }
            override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                main.post {
                    resolving = false
                    val host = serviceInfo.host?.hostAddress
                    if (host != null) {
                        found[serviceInfo.serviceName] = Found(serviceInfo.serviceName, host, serviceInfo.port)
                        macs.clear(); macs.addAll(found.keys.sorted())
                        val preferred = preferredMac
                        if (preferred != null && currentMac != preferred && found.containsKey(preferred)) link?.cancel()
                        connectIfNeeded()
                    }
                    resolveNext()
                }
            }
        })
    }

    fun choose(name: String) {
        preferredMac = name
        prefs.edit().putString("preferredMac", name).apply()
        if (currentMac != name) link?.cancel()
        connectIfNeeded()
    }

    private fun connectIfNeeded() {
        if (link != null || found.isEmpty()) return
        val target = found[preferredMac] ?: found.values.first()
        val host = target.host ?: return
        currentMac = target.name
        val l = LineConnection(host, target.port)
        link = l
        l.onConnected = {
            if (l === link) {
                connected = true
                l.send(Packet(hello = deviceName()))
            }
        }
        l.onClosed = {
            if (l === link) {
                connected = false
                val pending = HashMap(waiting)
                waiting.clear()
                pending.values.forEach { it(null) }
                macName = null
                link = null
                scheduleRetry()
            }
        }
        l.onPacket = { p ->
            p.hello?.let { macName = it }
            p.face?.let { onFace?.invoke(it) }
            val command = p.command
            if (command != null) {
                val done = p.callID?.let { waiting.remove(it) }
                if (done != null) done(p) else onCommand?.invoke(command)
            }
        }
        l.start()
    }

    fun send(packet: Packet) { link?.send(packet) }

    /** Sends a request to the Mac and calls back with its reply (null if the Mac went away). */
    fun request(packet: Packet, done: (Packet?) -> Unit) {
        val l = link
        if (l == null || !connected) { done(null); return }
        val id = UUID.randomUUID().toString()
        waiting[id] = done
        l.send(packet.copy(callID = id))
    }

    private fun deviceName(): String =
        (Build.MODEL ?: "Android").let { if (it.startsWith(Build.MANUFACTURER, true)) it else "${Build.MANUFACTURER} $it" }
}
